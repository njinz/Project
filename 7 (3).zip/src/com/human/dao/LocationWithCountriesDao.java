package com.human.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.human.crl.util.DBConn;
import com.human.dto.LocationsWithCountriesDto;

public class LocationWithCountriesDao {
	
	
	public ArrayList<LocationsWithCountriesDto> JobsWithEmployeesSelect(String a) {
		ArrayList<LocationsWithCountriesDto> dtos = new ArrayList<LocationsWithCountriesDto>();
		
		DBConn.getInstance();
		String sql = "select c.country_id,c.country_name,l.location_id,"
				+ "l.street_address,l.postal_code,l.city "
				+ "from locations l, countries c "
				+ "where l.country_id = '%s' and c.country_id = '%s' "
				+ "order by c.country_id ,c.country_name";
		sql=String.format(sql,a,a);
		
		ResultSet rs = DBConn.statementQuery(sql);

		try {
			while (rs.next()) {
				LocationsWithCountriesDto dto = new LocationsWithCountriesDto();
				
			
				dto.setCountry_id(rs.getString("country_id"));
				dto.setCountry_name(rs.getString("country_name"));
				dto.setLocation_id(rs.getInt("location_id"));
				dto.setStreet_address(rs.getString("street_address"));
				dto.setPostal_code(rs.getString("postal_code"));
				dto.setCity(rs.getString("city"));

				dtos.add(dto);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}

	public ArrayList<LocationsWithCountriesDto> JobsWithEmployeesSelectsle() {
		ArrayList<LocationsWithCountriesDto> dtos = new ArrayList<LocationsWithCountriesDto>();
		
		DBConn.getInstance();
		String sql = "select c.country_id,c.country_name,l.location_id,"
				+ "l.street_address,l.postal_code,l.city "
				+ "from locations l, countries c "
				+ "where l.country_id = c.country_id "
				+ "order by c.country_id ,c.country_name";
		sql=String.format(sql);
		
		ResultSet rs = DBConn.statementQuery(sql);

		try {
			while (rs.next()) {
				LocationsWithCountriesDto dto = new LocationsWithCountriesDto();
				
			
				dto.setCountry_id(rs.getString("country_id"));
				dto.setCountry_name(rs.getString("country_name"));
				dto.setLocation_id(rs.getInt("location_id"));
				dto.setStreet_address(rs.getString("street_address"));
				dto.setPostal_code(rs.getString("postal_code"));
				dto.setCity(rs.getString("city"));

				dtos.add(dto);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}

	
}