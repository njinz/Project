package com.human.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.human.crl.util.DBConn;
import com.human.dto.RegionsDto;

public class RegionsDao {
	
	
	public int insert(RegionsDto dto) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="insert into regions "
				+ "values"+"(%d,'%s')";

		sql=String.format(sql,dto.getId(),dto.getName());
		
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public int update(int a ,String name) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="update regions "
						+"set region_name ='%s' " +"where region_id = %d";
		sql=String.format(sql,name,a);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public int delete(int no) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="delete regions "
						+"where region_id = %d";
		sql=String.format(sql,no);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public ArrayList<RegionsDto> select(){
		ArrayList<RegionsDto> dtos=new ArrayList<RegionsDto>();
		DBConn.getInstance();
		String sql="select * from regions";
		ResultSet rs = DBConn.statementQuery(sql);
		try {
			while(rs.next()) {
				RegionsDto dto=new RegionsDto();
				dto.setId(rs.getInt("region_id"));
				dto.setName(rs.getString("region_name"));
				
				dtos.add(dto);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return dtos;
	}
	
}
