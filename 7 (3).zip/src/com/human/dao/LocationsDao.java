package com.human.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.human.crl.util.DBConn;
import com.human.dto.LocationsDto;

public class LocationsDao {
	
	
	public int insert(LocationsDto dto) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="insert into locations "
				+ "values"+"(%d,'%s','%s','%s','%s','%s')";

		sql=String.format(sql,dto.getLocation_id(),dto.getStreet_address(),
				dto.getPostal_code(),dto.getCity(),dto.getState_province(),dto.getCountry_id());
		
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public int updateAll(int location ,String street,String code,String city,String state ) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="update locations "
						+"set Street_Address ='%s',Postal_code='%s',city ='%s',State_Province= '%s '" +"where location_id = %d";
		sql=String.format(sql,street,code,city,state,location);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	public int updateStreet(int location ,String street) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="update locations "
						+"set Street_Address ='%s' " +"where location_id = %d";
		sql=String.format(sql,street,location);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public int updateState(int location,String state ) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="update locations "
						+"set State_Province= '%s'" +"where location_id = %d";
		sql=String.format(sql,state,location);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public int updatePost(int location ,String code) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="update locations "
						+"set Postal_code='%s' " +"where location_id = %d";
		sql=String.format(sql,code);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public int updateCity(int location,String city) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="update locations "
						+"set city ='%s' " +"where location_id = %d";
		sql=String.format(sql,city,location);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public int delete(int no) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="delete locations "
						+"where location_id = %d";
		sql=String.format(sql,no);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public ArrayList<LocationsDto> select(){
		ArrayList<LocationsDto> dtos=new ArrayList<LocationsDto>();
		DBConn.getInstance();
		String sql="select * from locations";
		ResultSet rs = DBConn.statementQuery(sql);
		try {
			while(rs.next()) {
				LocationsDto dto=new LocationsDto();
				dto.setLocation_id(rs.getInt("location_id"));
				dto.setStreet_address(rs.getString("street_address"));
				dto.setPostal_code(rs.getString("postal_code"));
				dto.setCity(rs.getString("city"));
				dto.setState_province(rs.getString("state_province"));
				dto.setCountry_id(rs.getString("country_id"));
				
				dtos.add(dto);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return dtos;
	}
	
}
