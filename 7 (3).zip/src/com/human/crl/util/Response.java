package com.human.crl.util;

import java.util.ArrayList;

import com.human.dto.RegionsDto;
import com.human.dto.LocationsDto;
import com.human.dto.CountriesDto;
import com.human.dto.LocationsWithCountriesDto;


public class Response {
	private ArrayList<CountriesDto> arrPersonDto =null;
	private int resultValue=0;
	
	private ArrayList<RegionsDto> arrPersonDto2 =null;
	private int resultValue2=0;
	
	private ArrayList<LocationsDto> arrPersonDto3 =null;
	private int resultValue3=0;
	
	private ArrayList<LocationsWithCountriesDto> arrPersonDto4 =null;
	private int resultValue4=0;
	
	
	
	public ArrayList<CountriesDto> getArrPersonDto() {
		return arrPersonDto;
	}
	public void setArrPersonDto(ArrayList<CountriesDto> arrPersonDto) {
		this.arrPersonDto = arrPersonDto;
	}
	public int getResultValue() {
		return resultValue;
	}
	public void setResultValue(int resultValue) {
		this.resultValue = resultValue;
	}
	
	
	public ArrayList<RegionsDto> getArrPersonDto2() {
		return arrPersonDto2;
	}
	public void setArrPersonDto2(ArrayList<RegionsDto> arrPersonDto2) {
		this.arrPersonDto2 = arrPersonDto2;
	}
	public int getResultValue2() {
		return resultValue2;
	}
	public void setResultValue2(int resultValue2) {
		this.resultValue2 = resultValue2;
	}
	
	
	public ArrayList<LocationsDto> getArrPersonDto3() {
		return arrPersonDto3;
	}
	public void setArrPersonDto3(ArrayList<LocationsDto> arrPersonDto3) {
		this.arrPersonDto3 = arrPersonDto3;
	}
	public int getResultValue3() {
		return resultValue3;
	}
	public void setResultValue3(int resultValue3) {
		this.resultValue3 = resultValue3;
	}
	
	
	public ArrayList<LocationsWithCountriesDto> getArrPersonDto4() {
		return arrPersonDto4;
	}
	public void setArrPersonDto4(ArrayList<LocationsWithCountriesDto> arrPersonDto4) {
		this.arrPersonDto4 = arrPersonDto4;
	}
	public int getResultValue4() {
		return resultValue4;
	}
	public void setResultValue4(int resultValue4) {
		this.resultValue4 = resultValue4;
	}
	
	

	
}
