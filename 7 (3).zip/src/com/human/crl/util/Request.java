package com.human.crl.util;

import com.human.dto.RegionsDto;
import com.human.dto.LocationsDto;
import com.human.dto.CountriesDto;
import com.human.dto.LocationsWithCountriesDto;;

public class Request {
	private CountriesDto personDto=null;
	private RegionsDto personDto2=null;
	private LocationsDto personDto3=null;
	private LocationsWithCountriesDto personDto4=null;
	


	public CountriesDto getPersonDto() {
		return personDto;
	}
	public RegionsDto getPersonDto2() {
		return personDto2;
	}
	
	
	public void setPersonDto(CountriesDto personDto) {
		this.personDto = personDto;
	}
	
	public void setPersonDto2(RegionsDto personDto2) {
		this.personDto2 = personDto2;
	}
	
	
	public LocationsDto getPersonDto3() {
		return personDto3;
	}
	public void setPersonDto3(LocationsDto personDto3) {
		this.personDto3 = personDto3;
	}
	
	public LocationsWithCountriesDto getPersonDto4() {
		return personDto4;
	}
	public void setPersonDto4(LocationsWithCountriesDto personDto4) {
		this.personDto4 = personDto4;
	}

	
	
	

}
