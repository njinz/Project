package com.human.dto;

import java.util.Date;
//�����͸� �������� util �������� sql


public class RegionsDto {
	private int region_id;
	private String region_name;
	
	
	public RegionsDto() {}
	public RegionsDto(int a,String st) {
		
		
		this.region_id = a;
		this.region_name = st;
	}
	
	
	@Override
	public String toString() {
		return "regions [region_id=" + region_id + ", region_name=" + region_name + "]";
	}
	public int getId() {
		return region_id;
	}
	public void setId(int id) {
		this.region_id = id;
	}
	public String getName() {
		return region_name;
	}
	public void setName(String name) {
		this.region_name = name;
	}
	

	
	
}
