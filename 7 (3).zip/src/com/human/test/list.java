package com.human.test;

import java.util.Scanner;

import com.human.controller.CountriesDelete;
import com.human.controller.RegionsDelete;
import com.human.controller.LocationsDelete;
import com.human.controller.RCLExecute;
import com.human.controller.CountriesInsert;
import com.human.controller.RegionsInsert;
import com.human.controller.LocationsInsert;
import com.human.controller.CountriesSelect;
import com.human.controller.RegionsSelect;
import com.human.crl.util.Request;
import com.human.crl.util.Response;
import com.human.controller.LocationsSelect;
import com.human.controller.CountriesUpdate;
import com.human.controller.RegionsUpdate;
import com.human.controller.LocationsUpdateAll;
import com.human.controller.LocationsWithCountries;
import com.human.dto.CountriesDto;


public class list {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		String st=null;
		String st2=null;
		boolean flag = true;
		boolean flag2 = true;
		
		RCLExecute pe = null;
		Response response=new Response();
		Request request=new Request();
		
		
		while(flag2) {
			System.out.println("1.regions 2.countries 3.locations 4. 0.����");
			flag = true;
			st2=sc.nextLine();
			switch(st2) {
			case "1":
				while(flag) {
					System.out.println("1 �Է�  2.��������  3.��������  4.��ü�������  0.����");
					st=sc.nextLine();
					switch(st) {
					case "1":
						pe=new RegionsInsert();
						st=null;
						pe.execute(request, response);
						break;
					case "2":
						pe=new RegionsUpdate();
						st=null;
						pe.execute(request, response);
						break;
					case "3":
						pe=new RegionsDelete();
						st=null;
						pe.execute(request, response);
						break;
					case "4":
						pe=new RegionsSelect();
						st=null;
						pe.execute(request, response);
						break;
					case "0":
						System.out.println("����");
						st=null;
						
						flag = false;
						break;
					default:
						System.out.println("�߸� �Է�");
						break;
					
					}

				}
				break;
			case "2":
				while(flag) {
					System.out.println("1 �Է�  2.��������  3.��������  4.��ü������� 5.���� 0.����");
					st=sc.nextLine();
					switch(st) {
					case "1":
						pe=new CountriesInsert();
						st=null;
						pe.execute(request, response);
						break;
					case "2":
						pe=new CountriesUpdate();
						st=null;
						pe.execute(request, response);
						break;
					case "3":
						pe=new CountriesDelete();
						st=null;
						pe.execute(request, response);
						break;
					case "4":
						pe = new CountriesSelect();
						st=null;
						pe.execute(request, response);
						break;
					case "5":
						pe = new LocationsWithCountries();
						st=null;
						pe.execute(request, response);
						break;
					case "0":
						System.out.println("����");
						flag = false;
						st=null;
						
						break;
					default:
						System.out.println("�߸� �Է�");
						break;
					
					}			
				}

				break;
				
			case"3":
				while(flag) {
					System.out.println("1 �Է�  2.��������  3.��������  4.��ü�������  0.����");
					st=sc.nextLine();
					switch(st) {
					case "1":
						pe=new LocationsInsert();
						st=null;
						pe.execute(request, response);
						break;
					case "2":
						pe=new LocationsUpdateAll();
						st=null;
						pe.execute(request, response);
						break;
					case "3":
						pe=new LocationsDelete();
						st=null;
						pe.execute(request, response);
						break;
					case "4":
						pe = new LocationsSelect();
						st=null;
						pe.execute(request, response);
						break;
					case "0":
						System.out.println("����");
						flag = false;
						st=null;
						
						break;
					default:
						System.out.println("�߸� �Է�");
						break;
					
					}			
				}

				break;
			case "0":
				System.out.println("����");
				flag2 = false;
				break;
			default:
				break;
			}
		}

	}

}
