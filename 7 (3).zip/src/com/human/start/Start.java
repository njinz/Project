package com.human.start;

import com.human.test.list;

public class Start {
	public static void main(String[] args) {	
		list li = new list();
		li.main(args);
	}
	
}
