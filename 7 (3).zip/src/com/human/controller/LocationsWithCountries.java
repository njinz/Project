package com.human.controller;

import java.util.ArrayList;


import com.human.dao.LocationWithCountriesDao;
import com.human.dao.LocationsDao;
import com.human.dto.LocationsWithCountriesDto;
import com.human.dao.CountriesDao;
import com.human.dto.CountriesDto;
import com.human.dto.LocationsDto;
import com.human.crl.util.DBConn;
import com.human.crl.util.Request;
import com.human.crl.util.Response;

public class LocationsWithCountries implements RCLExecute {
	
	public void execute() {
		Object request = new LocationsWithCountriesDto();
		Object response = new ArrayList<Integer>();
		
	}
	@Override
	public void execute(Request request, Response response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Request request, Response response) {
		LocationsWithCountriesDto dto = new LocationsWithCountriesDto();		
		
		System.out.println("�˻��� ���� id �Է�");
		String a=DBConn.inputString();
		
		boolean flag = true;
		int i = 0;
		while(flag) {
		

//			CountriesDao codao = new CountriesDao();
//
//			response.setArrPersonDto(codao.select());
//			ArrayList<CountriesDto> codtos = response.getArrPersonDto();
//			for(CountriesDto codto:codtos) {
//				
//				if(a.equals(codto.getCountry_id())) {				
//					i=1;
//					flag = false;
//				}
//				else if((a.equals(codto.getCountry_id()))&&!(a.equals(codto.getCountry_id()))) {	
//					
//					i=2;
//					flag = false;
//				}
//			}
//			if(i==0) {
//			System.out.println("�˻��� ���� id ���Է�");
//			a=DBConn.inputString();
//		}
//		if(i==2) {
//			System.out.println("ã�� �������� ������ �����ϴ�");
//		}
//		
//	}
			
			
//			LocationsDao lodao = new LocationsDao();
//	
//			response.setArrPersonDto3(lodao.select());
//			ArrayList<LocationsDto> lodtos = response.getArrPersonDto3();
//			for(LocationsDto lodto:lodtos) {
//				
//				if((a.equals(lodto.getCountry_id()))) {	
//					
//					i=1;
//					flag = false;
//				}
//				else if(!(a.equals(lodto.getCountry_id()))) {	
//					
//					i=2;
//					flag = false;
//				}
//			}
//			
//			if(i==0) {
//				System.out.println("�˻��� ���� id ���Է�");
//				a=DBConn.inputString();
//			}
//			if(i==2) {
//				System.out.println("ã�� �������� ������ �����ϴ�");
//			}
//			
//		}
			
			
			LocationWithCountriesDao lwcdao = new LocationWithCountriesDao();
			CountriesDao coDao = new CountriesDao();
			LocationsDao loDao = new LocationsDao();
			
			
			response.setArrPersonDto4(lwcdao.JobsWithEmployeesSelectsle());
			response.setArrPersonDto(coDao.select());
			response.setArrPersonDto3(loDao.select());
			
			ArrayList<CountriesDto> codtos = response.getArrPersonDto();
			ArrayList<LocationsWithCountriesDto> lwcdtos = response.getArrPersonDto4();
			ArrayList<LocationsDto> lodtos = response.getArrPersonDto3();
			
			for(CountriesDto codto:codtos) {
				for(LocationsDto lodto:lodtos) {
					if((a.equals(codto.getCountry_id()))&&(a.equals(lodto.getCountry_id()))) {	
						
						i=1;
						flag = false;
						break;
					}
					
					else if((a.equals(codto.getCountry_id()))&&(!(a.equals(lodto.getCountry_id())))) {	
						
						i=2;
						flag = false;
						
					}
				}
				
		
			}
			
			
			if(i==0) {
				System.out.println("�˻��� ���� id ���Է�");
				a=DBConn.inputString();
			}
			if(i==2) {
				System.out.println("ã�� �������� ������ �����ϴ�");
			}
			
		}
			
			
			
			
			
//			for(LocationsWithCountriesDto lwcdto:lwcdtos) {
//				for(CountriesDto codto:codtos) {
//					
//					if((a.equals(codto.getCountry_id()))&&!(a.equals(lwcdto.getCountry_id()))) {	
//						
//						i=2;
//						flag = false;
//					}
//					else if((a.equals(lwcdto.getCountry_id()))) {	
//						
//						i=1;
//						flag = false;
//					}
//					System.out.println(codto.getCountry_id());
//					
//				}
//		
//			}
//			
//			if(i==0) {
//				System.out.println("�˻��� ���� id ���Է�");
//				a=DBConn.inputString();
//			}
//			if(i==2) {
//				System.out.println("ã�� �������� ������ �����ϴ�");
//			}
//			
//		}
		
		
		dto.setCountry_id(a);
		request.setPersonDto4(dto);
	}

	@Override
	public void logic(Request request, Response response) {
		LocationWithCountriesDao dao = new LocationWithCountriesDao();
		LocationsWithCountriesDto dto = request.getPersonDto4();
		response.setArrPersonDto4(dao.JobsWithEmployeesSelect(dto.getCountry_id()));
	}

	@Override
	public void outputView(Request request, Response response) {
		
		if(response!=null) {
			ArrayList<LocationsWithCountriesDto> dtos = response.getArrPersonDto4();
		
			for(LocationsWithCountriesDto dto:dtos) {	
				System.out.println(dto);
			}
			
		}else {
			System.out.println("�����������ϴ�.");
		}
		
	}
	
}
