package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.crl.util.DBConn;
import com.human.crl.util.Request;
import com.human.crl.util.Response;
import com.human.dao.LocationsDao;
import com.human.dto.LocationsDto;

public class LocationsUpdateAll implements RCLExecute {

	public void execute() {
		Object request = new LocationsDto();
		Object response = new ArrayList<Integer>();
		
	}
	@Override
	public void execute(Request request, Response response) {
		// TODO Auto-generated method stub
		inputView(request,response);
		logic(request,response);
		outputView(request,response);
	}

	@Override
	public void inputView(Request request, Response response) {//��ü ����
		// TODO Auto-generated method stub
		System.out.println("������ location_id �Է�");
		int location=DBConn.inputInt();
		System.out.println("�ּ��Է�");
		String street = DBConn.inputString();
		System.out.println("������ȣ�Է�");
		String post = DBConn.inputString();
		System.out.println("���� �Է�");
		String city = DBConn.inputString();
		System.out.println("�Ҽ��� �Է� ������ �Է°����Է�");
		String state = DBConn.inputString();
		
		LocationsDto dto = new LocationsDto();
		dto.setLocation_id(location);
		dto.setStreet_address(street);
		dto.setCity(city);
		dto.setPostal_code(post);
		dto.setState_province(state);
		
		request.setPersonDto3(dto);
	}

	@Override
	public void logic(Request request, Response response) {
		// TODO Auto-generated method stub
		LocationsDto dto = request.getPersonDto3();	
		LocationsDao dao = new LocationsDao();
		int i=dao.updateAll(dto.getLocation_id(),dto.getStreet_address(),dto.getPostal_code(),dto.getCity(),dto.getState_province());
		response.setResultValue(i);
	}

	@Override
	public void outputView(Request request, Response response) {
		// TODO Auto-generated method stub
		System.out.println("Locataion_id: "+request.getPersonDto3().getLocation_id()+" ��");
		System.out.println("�ּҰ� "+request.getPersonDto3().getStreet_address()+"�� �����Ǿ����ϴ�.");
		System.out.println("���ð� "+request.getPersonDto3().getCity()+"�� �����Ǿ����ϴ�..");
		System.out.println("������ȣ�� "+request.getPersonDto3().getPostal_code()+"�� �����Ǿ����ϴ�.");
		System.out.println("�ְ� '"+request.getPersonDto3().getState_province() + "'�� �����Ǿ����ϴ�.");
	}

	

}
