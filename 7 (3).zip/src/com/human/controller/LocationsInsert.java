package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.crl.util.DBConn;
import com.human.crl.util.Request;
import com.human.crl.util.Response;
import com.human.dao.LocationsDao;
import com.human.dto.LocationsDto;

public class LocationsInsert implements RCLExecute{
	
	public void execute() {
		Object request = new LocationsDto();
		Object response = new ArrayList<Integer>();
		
	}
	@Override
	public void execute(Request request, Response response) {
		inputView(request,response);
		logic(request,response);
		outputView(request,response);
	}
	@Override
	public void inputView(Request request, Response response) {
		System.out.println("locations ���� �Է��ϼ���");
		System.out.println("location_id �Է�");
		int no=DBConn.inputInt();
		System.out.println("street_address �Է�");
		String name1 = DBConn.inputString();
		System.out.println("postal_code �Է�");
		String name2=DBConn.inputString();
		System.out.println("city �Է�");
		String name3 = DBConn.inputString();
		System.out.println("state_province �Է�");
		String name4=DBConn.inputString();
		System.out.println("country_id �Է�");
		String name5 = DBConn.inputString();
		
		
		LocationsDto dto = new LocationsDto();
		dto.setLocation_id(no);
		dto.setStreet_address(name1);
		dto.setPostal_code(name2);
		dto.setCity(name3);
		dto.setState_province(name4);
		dto.setCountry_id(name5);
		
		request.setPersonDto3(dto);
	
	}
	@Override
	public void logic(Request request, Response response) {
		LocationsDto dto = request.getPersonDto3();	
		LocationsDao dao = new LocationsDao();
		int i=dao.insert(dto);
		response.setResultValue(i);
	}
	@Override
	public void outputView(Request request, Response response) {
		System.out.println(response.getResultValue());
	}

}
