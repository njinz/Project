package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.crl.util.DBConn;
import com.human.crl.util.Request;
import com.human.crl.util.Response;
import com.human.dao.LocationsDao;
import com.human.dto.LocationsDto;

public class LocationsUpdateCity implements RCLExecute {

	public void execute() {
		Object request = new LocationsDto();
		Object response = new ArrayList<Integer>();
		
	}
	@Override
	public void execute(Request request, Response response) {
		// TODO Auto-generated method stub
		inputView(request,response);
		logic(request,response);
		outputView(request,response);
	}

	@Override
	public void inputView(Request request, Response response) {//���� ����
		// TODO Auto-generated method stub
		System.out.println("������ location_id �Է�");
		int location=DBConn.inputInt();
		System.out.println("���� �Է�");
		String city = DBConn.inputString();
		
		LocationsDto dto = new LocationsDto();
		dto.setLocation_id(location);
		dto.setCity(city);
		request.setPersonDto3(dto);
	}

	@Override
	public void logic(Request request, Response response) {
		// TODO Auto-generated method stub
		LocationsDto dto = request.getPersonDto3();	
		LocationsDao dao = new LocationsDao();
		int i=dao.updateCity(dto.getLocation_id(),dto.getCity());
		response.setResultValue(i);
	}

	@Override
	public void outputView(Request request, Response response) {
		// TODO Auto-generated method stub
		System.out.println("Locataion_id: "+request.getPersonDto3().getLocation_id()+" ��");
		System.out.println("���ð� "+request.getPersonDto3().getCity()+"�� �����Ǿ����ϴ�..");
	}

	

}
