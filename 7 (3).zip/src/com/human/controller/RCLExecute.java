package com.human.controller;
import com.human.crl.util.Request;
import com.human.crl.util.Response;

public interface RCLExecute {
	public void execute();
	public void execute(Request request,Response response);
	
	public void inputView(Request request,Response response);
	
	public void logic(Request request,Response response);
	
	public void outputView(Request request,Response response);
	
}
