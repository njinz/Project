package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.crl.util.DBConn;
import com.human.crl.util.Request;
import com.human.crl.util.Response;
import com.human.dao.RegionsDao;
import com.human.dto.RegionsDto;

public class RegionsDelete implements RCLExecute {

	public void execute() {
		Object request = new RegionsDto();
		Object response = new ArrayList<Integer>();

	}
	@Override
	public void execute(Request request, Response response) {
		// TODO Auto-generated method stub
		inputView(request,response);
		logic(request,response);
		outputView(request,response);
	}

	@Override
	public void inputView(Request request, Response response) {
		// TODO Auto-generated method stub
		System.out.println("������ id �Է�");
		int a=DBConn.inputInt();
		RegionsDto dto = new RegionsDto();
		dto.setId(a);
		request.setPersonDto2(dto);
		
	}

	@Override
	public void logic(Request request, Response response) {
		// TODO Auto-generated method stub
		RegionsDto dto = request.getPersonDto2();	
		RegionsDao dao = new RegionsDao();
		
		int i=dao.delete(dto.getId());
		dao.delete(dto.getId());
		
		response.setResultValue(i);
	}

	@Override
	public void outputView(Request request, Response response) {
		// TODO Auto-generated method stub
		RegionsDto req =request.getPersonDto2();
		
		
		System.out.println("id "+req.getId()+"�� �����Ͽ����ϴ�");
		

		
	}

}
