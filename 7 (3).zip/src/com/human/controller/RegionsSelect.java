package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.crl.util.DBConn;
import com.human.crl.util.Request;
import com.human.crl.util.Response;
import com.human.dao.RegionsDao;
import com.human.dto.RegionsDto;

public class RegionsSelect implements RCLExecute {
	
	public void execute() {
		Object request = new RegionsDto();
		Object response = new ArrayList<Integer>();
	
	}
	@Override
	public void execute(Request request, Response response) {
		// TODO Auto-generated method stub
		inputView(request,response);
		logic(request,response);
		outputView(request,response);
	}
	@Override
	public void inputView(Request request, Response response) {
		// TODO Auto-generated method stub
		System.out.println("��ü���� ǥ��");
	}
	
	@Override
	public void logic(Request request, Response response) {
		// TODO Auto-generated method stub
	
		RegionsDao dao = new RegionsDao();		
		response.setArrPersonDto2(dao.select());
		
	
	}

	@Override
	public void outputView(Request request, Response response) {
		// TODO Auto-generated method stub
	
		if(response!=null) {
			ArrayList<RegionsDto> dtos=response.getArrPersonDto2();
			for(RegionsDto dto:dtos) {
				System.out.println(dto);
			}
		}else {
			System.out.println("ȸ���� �����ϴ�");
		}
		
	}

}
