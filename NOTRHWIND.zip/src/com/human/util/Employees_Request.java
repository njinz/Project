package com.human.util;

import com.human.dto.EmployeesDto;

public class Employees_Request {
	private EmployeesDto employeesDto = null;

	
	public EmployeesDto getEmployeesDto() {
		return employeesDto;
	}

	public void setEmployeesDto(EmployeesDto employeesDto) {
		this.employeesDto = employeesDto;
	}
	
	

}
