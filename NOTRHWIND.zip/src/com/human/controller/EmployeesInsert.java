package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.util.DBConn;
import com.human.util.Employees_Request;
import com.human.util.Employees_Response;

public class EmployeesInsert implements EmployeesExecute {

	@Override
	public void execute() {
		EmployeesDto request = new EmployeesDto();
		ArrayList<Integer> response  = new ArrayList<Integer>();
	}

	@Override
	public void execute(Employees_Request request, Employees_Response response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Employees_Request request, Employees_Response response) {
		System.out.println("-------ȸ�������Է¶�-------");
		
		System.out.println("��� ��ȣ �Է�");
		int EmployeeID = DBConn.inputInt();
		
		System.out.println("LastName�Է�");
		String LastName = DBConn.inputString();
		
		System.out.println("FirstName�Է�");
		String FirstName = DBConn.inputString();
		
		System.out.println("Title�Է�");
		String Title = DBConn.inputString();
		
		System.out.println("Title Of Courtesy�Է�");
		String TitleOfCourtesy = DBConn.inputString();
		
		System.out.println("���� �Է�");
		Date BirthDate = DBConn.inputDate();
		
		System.out.println("�Ի��� �Է�");
		Date HireDate = DBConn.inputDate();
		
		System.out.println("�ּ� �Է�");
		String Address = DBConn.inputString();
		
		System.out.println("���� �Է�");
		String City = DBConn.inputString();
		
		System.out.println("���� �Է�");
		String Region = DBConn.inputString();
		
		System.out.println("������ȣ �Է�");
		String PostalCode = DBConn.inputString();
		
		System.out.println("���� �Է�");
		String Country = DBConn.inputString();
		
		System.out.println("����ȭ��ȣ �Է�");
		String HomePhone = DBConn.inputString();
		
		System.out.println("������ȣ �Է�");
		String Extension = DBConn.inputString();
		
		System.out.println("Photo �Է�");
		String Photo = DBConn.inputString();
		
		System.out.println("�޸����");
		String Notes = DBConn.inputString();
		
		System.out.println("��� ��ȣ �Է�");
		int ReportsTo = DBConn.inputInt();
		
		System.out.println("PhotoPath �Է�");
		String PhotoPath = DBConn.inputString();
		
		EmployeesDto dto = new EmployeesDto();
			dto.setEmployeeID(EmployeeID);
			dto.setLastName(LastName);
			dto.setFirstName(FirstName);
			dto.setTitle(Title);
			dto.setTitleOfCourtesy(TitleOfCourtesy);
			dto.setBirthDate(BirthDate);
			dto.setHireDate(HireDate);
			dto.setAddress(Address);
			dto.setCity(City);
			dto.setRegion(Region);
			dto.setPostalCode(PostalCode);
			dto.setCountry(Country);
			dto.setHomePhone(HomePhone);
			dto.setExtension(Extension);
			dto.setPhoto(Photo);
			dto.setNotes(Notes);
			dto.setReportsTo(ReportsTo);
			dto.setPhotoPath(PhotoPath);
			request.setEmployeesDto(dto);
		
	}

	@Override
	public void logic(Employees_Request request, Employees_Response response) {
		EmployeesDto dto = request.getEmployeesDto();
		EmployeesDao dao = new EmployeesDao();
		int i = dao.insert(dto);
		response.setResultValue(i);
		
	}

	@Override
	public void outputView(Employees_Request request, Employees_Response response) {
		System.out.println(response.getResultValue());
		
	}

}

/*	    private int EmployeeID;
private String LastName;
private String FirstName;
private String Title;
private String TitleOfCourtesy;
private Date BirthDate;
private Date HireDate;

private String Address;
private String City;
private String Region;
private String PostalCode;
private String Country;
private String HomePhone;
private String Extension;
private String Photo;
private String Notes;
private int ReportsTo;
private String PhotoPath;*/