package com.human.controller;

import java.util.ArrayList;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.util.DBConn;
import com.human.util.Employees_Request;
import com.human.util.Employees_Response;

public class EmployeesDelete implements EmployeesExecute {

	@Override
	public void execute() {
		EmployeesDto request = new EmployeesDto();
		ArrayList<Integer> response = new ArrayList<Integer>();
		
	}

	@Override
	public void execute(Employees_Request request, Employees_Response response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Employees_Request request, Employees_Response response) {
		System.out.println("������ �����ȣ�� �Է��ϼ���.");
		System.out.println("�����ȣ�Է�");
		int no = DBConn.inputInt();
		
		EmployeesDto dto = new EmployeesDto();
		dto.setEmployeeID(no);
		request.setEmployeesDto(dto);
		
	}

	@Override
	public void logic(Employees_Request request, Employees_Response response) {
		EmployeesDto dto = request.getEmployeesDto();
		EmployeesDao dao = new EmployeesDao();
		int i = dao.delete(dto.getEmployeeID());
		response.setResultValue(i);
		
	}

	@Override
	public void outputView(Employees_Request request, Employees_Response response) {
		EmployeesDto req = request.getEmployeesDto();
		System.out.println("�����ȣ" + req.getEmployeeID()+ "�� �����͸� "+ 
		response.getResultValue() + "�� �����߽��ϴ�.");
		
	}

}
