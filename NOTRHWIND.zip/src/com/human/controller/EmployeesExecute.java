package com.human.controller;

import com.human.util.Employees_Request;
import com.human.util.Employees_Response;

public interface EmployeesExecute {
	
	public void execute();
	
	public void execute(Employees_Request request, Employees_Response response);
	public void inputView(Employees_Request request, Employees_Response response);
	public void logic(Employees_Request request, Employees_Response response);
	public void outputView(Employees_Request request, Employees_Response response);
}
