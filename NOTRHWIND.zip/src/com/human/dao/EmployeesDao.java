package com.human.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.human.dto.EmployeesDto;
import com.human.util.DBConn;

public class EmployeesDao {
	//insert
	public int insert(EmployeesDto dto) {
		int returnValue=0;
		DBConn.getInstance();
		String sql= "insert into Employees "
				+ "values"
				+ "(%d,'%s','%s','%s','%s',"
				+ "to_date('%s', 'yyyy-mm-dd'),"
				+ "to_date('%s', 'yyyy-mm-dd'),"
				+ "'%s','%s','%s','%s','%s','%s','%s','%s','%s',%d,'%s')";

		
		sql=String.format(sql, dto.getEmployeeID(),dto.getLastName(),dto.getFirstName(),
				dto.getTitle(),dto.getTitleOfCourtesy(),DBConn.dateToString(dto.getBirthDate()),DBConn.dateToString(dto.getHireDate()),
				dto.getAddress(),dto.getCity(),dto.getRegion(),dto.getPostalCode(),
				dto.getCountry(),dto.getHomePhone(),dto.getExtension(),dto.getPhoto(),
				dto.getNotes(),dto.getReportsTo(),dto.getPhotoPath());
		
	
		
		
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	
	//update
	public int update(String LastName, String FirstName, int EmployeeID ) {
		int returnValue=0;
		DBConn.getInstance();
		String sql="update Employees "+"set LastName = '%s',"+ "FirstName = '%s' " +
		" where EmployeeID=%d";
		sql=String.format(sql, LastName,FirstName,EmployeeID);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	//delete
	public int delete(int EmployeeID) {
		int returnValue=0;
		DBConn.getInstance();
		String sql = "delete Employees "+"where EmployeeID=%d";
		sql=String.format(sql, EmployeeID);
		returnValue=DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	//select 
	public ArrayList<EmployeesDto> select(){
		ArrayList<EmployeesDto>dtos = new ArrayList<EmployeesDto>();
		DBConn.getInstance();
//		String sql="select * from Employees";
		String userInput = DBConn.inputString();
		System.out.println(userInput);
		String sql = userInput;
		ResultSet rs = DBConn.StatementQuery(sql);
		
		try {
			while(rs.next()) {
				EmployeesDto dto = new EmployeesDto();
				//dto�� ���
				dto.setEmployeeID(rs.getInt("EmployeeID"));
				dto.setLastName(rs.getString("LastName"));
				dto.setFirstName(rs.getString("FirstName"));
				dto.setTitle(rs.getString("Title"));
				dto.setTitleOfCourtesy(rs.getString("TitleOfCourtesy"));
				dto.setBirthDate(rs.getDate("BirthDate"));
				dto.setHireDate(rs.getDate("HireDate"));
				dto.setAddress(rs.getString("Address"));
				dto.setCity(rs.getString("City"));
				dto.setRegion(rs.getString("Region"));
				dto.setPostalCode(rs.getString("PostalCode"));
				dto.setCountry(rs.getString("Country"));
				dto.setHomePhone(rs.getString("HomePhone"));
				dto.setExtension(rs.getString("Extension"));
				dto.setPhoto(rs.getString("Photo"));
				dto.setNotes(rs.getString("Notes"));
				dto.setReportsTo(rs.getInt("ReportsTo"));
				dto.setPhotoPath(rs.getString("PhotoPath"));
				
				dtos.add(dto);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return dtos;
	}
	
}

















