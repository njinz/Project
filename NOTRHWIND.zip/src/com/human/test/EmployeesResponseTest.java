package com.human.test;

import com.human.controller.EmployeesDelete;
import com.human.controller.EmployeesExecute;
import com.human.controller.EmployeesInsert;
import com.human.controller.EmployeesSelect;
import com.human.controller.EmployeesUpdate;
import com.human.util.Employees_Request;
import com.human.util.Employees_Response;

public class EmployeesResponseTest {

	public static void main(String[] args) {
		
		int select=3;
		EmployeesExecute ee = null;
		Employees_Request request = new Employees_Request();
		Employees_Response response = new Employees_Response();
		
		switch(select) {
		case 0:
			ee = new EmployeesInsert();
			break;
		case 1:
			ee = new EmployeesUpdate();
			break;
		case 2:
			ee = new EmployeesDelete();
			break;
		case 3:
			ee = new EmployeesSelect();
			break;
		default: 
				break;
		}
		ee.execute(request, response);
	}

}
