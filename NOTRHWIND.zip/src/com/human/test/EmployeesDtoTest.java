package com.human.test;

import java.util.ArrayList;
import java.util.Date;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.util.DBConn;

public class EmployeesDtoTest {

	public static void main(String[] args) {
		//insert
		EmployeesDao dao= new EmployeesDao();
		EmployeesDto dto= new EmployeesDto();
		
		dto.setEmployeeID(3);
		dto.setLastName("SUZAN");
		dto.setFirstName("PHO");
		dto.setTitle("sales coordinator");
		dto.setTitleOfCourtesy("MS.");
		
//		dto.setBirthDate(DBConn.dateToString(new Date()));
//		dto.setHireDate(DBConn.dateToString(new Date()));
		dto.setBirthDate(new Date());
		dto.setHireDate(new Date());
		
		dto.setAddress("abcdef");
		dto.setCity("Seoul");
		dto.setRegion("GURO");
		dto.setPostalCode("62341");
		dto.setCountry("KOREA");
		dto.setHomePhone("5811214");
		dto.setExtension("0123");
		dto.setPhoto("yes");
		dto.setNotes("no");
		dto.setReportsTo(2);
		dto.setPhotoPath("sjpg");
		int result = dao.insert(dto);
		System.out.println(result);
		
//		EmployeesDao dao= new EmployeesDao();
		int result2 = dao.update("Bonnie", "Kim", 2);
		System.out.println(result2);
		
		int result3 = dao.delete(2);
		System.out.println(result3);
		
		ArrayList<EmployeesDto> dtos = dao.select();
		for(EmployeesDto dto2:dtos) {
			System.out.println(dto2);
		}
	}
	

}



		/*	    private int EmployeeID;
				private String LastName;
				private String FirstName;
				private String Title;
				private String TitleOfCourtesy;
				
				private Date BirthDate;
				private Date HireDate;
				
				private String Address;
				private String City;
				private String Region;
				private String PostalCode;
				private String Country;
				private String HomePhone;
				private String Extension;
				private String Photo;
				private String Notes;
				private int ReportsTo;
				private String PhotoPath;*/