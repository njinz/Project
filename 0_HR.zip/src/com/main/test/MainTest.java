package com.main.test;

import com.main.select.MainSwitch;


public class MainTest {

	public static void main(String[] args) {
		
		MainSwitch main = new MainSwitch();
		
		main.SwitchMenu();
	
	}

}
