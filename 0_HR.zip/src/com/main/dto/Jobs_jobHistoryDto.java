package com.main.dto;

public class Jobs_jobHistoryDto {
	//jobs job_history join dto
	private String jobId;
	private int departmentId;
	
	public Jobs_jobHistoryDto(){}

	public Jobs_jobHistoryDto(String jobId, int departmentId) {
		super();
		this.jobId = jobId;
		this.departmentId = departmentId;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	@Override
	public String toString() {
		return "jobs_jobHistoryDTO [jobId=" + jobId + ", departmentId=" + departmentId + "]";
	}
	
	
}
