package com.main.controller;

import java.util.ArrayList;

import com.main.dao.DeAndLocationsDao;
import com.main.dto.DeAndLocationsDto;
import com.main.util.Request;
import com.main.util.Response;

public class DeAndLocationsSelect implements MainExecute {

	@Override
	public void execute(Request request, Response response) {
		inputView(request,response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Request request, Response response) {
		System.out.println("Departments and Locations.");
		
	}

	@Override
	public void logic(Request request, Response response) {
		DeAndLocationsDao dao = new DeAndLocationsDao();
		response.setArrde_loDto(dao.DeWithLocationsSelect());
		
	}

	@Override
	public void outputView(Request request, Response response) {
		if(response!=null) {
			
			ArrayList<DeAndLocationsDto> dtos = response.getArrde_loDto();
			System.out.println("���������.");
			for(DeAndLocationsDto dto:dtos) {
				System.out.println(dto);
			}
		}else {
			System.out.println("������ �����ϴ�.");
		}
	}

}
