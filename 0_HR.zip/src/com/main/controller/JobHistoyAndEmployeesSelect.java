package com.main.controller;

import java.util.ArrayList;

import com.main.dao.JobHistoryWithEmployeesDao;
import com.main.dto.JobHistoryWithEmployeesDto;
import com.main.util.Request;
import com.main.util.Response;

public class JobHistoyAndEmployeesSelect implements MainExecute {
	@Override
	public void execute(Request request, Response response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Request request, Response response) {
		System.out.println("JobHistory and Employees.");
		
	}

	@Override
	public void logic(Request request, Response response) {
		JobHistoryWithEmployeesDao dao = new JobHistoryWithEmployeesDao();
		response.setArrJHDto(dao.JobsWithEmployeesSelect());
		
		
	}

	@Override
	public void outputView(Request request, Response response) {
		
		if(response!=null) {
			ArrayList<JobHistoryWithEmployeesDto> dtos = response.getArrJHDto();
			System.out.println("���������.");
			for(JobHistoryWithEmployeesDto dto:dtos) {
				System.out.println(dto);
			}
		}else {
			System.out.println("�����������ϴ�.");
		}
		
	}
	
}
