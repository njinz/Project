package com.main.controller;

import com.main.util.Request;
import com.main.util.Response;

public interface MainExecute {
	public void execute(Request request, Response response);
	public void inputView(Request request, Response response);
	public void logic(Request request, Response response);
	public void outputView(Request request, Response response);
	
	default void execute() {
		
	}
}
