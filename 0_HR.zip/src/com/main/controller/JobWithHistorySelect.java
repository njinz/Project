package com.main.controller;

import java.util.ArrayList;



import com.main.dao.JobsAndHistoryDao;
import com.main.dto.Jobs_jobHistoryDto;
import com.main.util.Request;
import com.main.util.Response;

public class JobWithHistorySelect implements MainExecute {


	@Override
	public void execute(Request request, Response response) {
		inputView(request, response);
		logic(request, response);
		outputView( request, response);
	}
	
	@Override
	public void inputView(Request request, Response response) {
		
		System.out.println("Jobs and Job_History");
	}

	@Override
	public void logic(Request request,Response response) {
		JobsAndHistoryDao dao = new JobsAndHistoryDao();
		response.setArrjhDto(dao.select_jh_jobs());
	}

	@Override
	public void outputView(Request request,Response response) {
		
		if(response!=null) {
			ArrayList<Jobs_jobHistoryDto> dtos = response.getArrjhDto();
			System.out.println("������ ������ �����ϴ�.");
			for(Jobs_jobHistoryDto dto:dtos) {
				System.out.println(dto);
			}
		
		}else {
			System.out.println("������ �����ϴ�.");
		}
		
	}

	
	
}
