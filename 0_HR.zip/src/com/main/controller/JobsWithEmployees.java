package com.main.controller;

import java.util.ArrayList;

import com.main.dao.JobsWithEmployeesDao;
import com.main.dto.JobsWithEmployeesDto;
import com.main.util.Request;
import com.main.util.Response;

public class JobsWithEmployees implements MainExecute {

	@Override
	public void execute(Request request, Response response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);

	}

	@Override
	public void inputView(Request request, Response response) {
		System.out.println("Jobs and Employees.");

	}

	@Override
	public void logic(Request request, Response response) {
		JobsWithEmployeesDao dao = new JobsWithEmployeesDao();
		response.setArrMainDto(dao.select());
	}

	@Override
	public void outputView(Request request, Response response) {
		if (response != null) {
			boolean flag = true;
			ArrayList<JobsWithEmployeesDto> dtos = response.getArrMainDto();
			System.out.println("���������� ������ �����ϴ�.");
		

				for (JobsWithEmployeesDto dto : dtos) {
					System.out.println(dto);
					flag = false;
				}
		
		} else {
			System.out.println("������ �����ϴ�.");
		}
	}
}
