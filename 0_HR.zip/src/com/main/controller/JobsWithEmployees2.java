package com.main.controller;

import java.util.ArrayList;

import com.human.jobs.util.DBConn;
import com.main.dao.JobsWithEmployeesDao;
import com.main.dto.JobsWithEmployeesDto;
import com.main.util.Request;
import com.main.util.Response;
import com.main.select.MainSwitch;

public class JobsWithEmployees2 implements MainExecute {

	@Override
	public void execute(Request request, Response response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);

	}

	@Override
	public void inputView(Request request, Response response) {
		System.out.println("ID�Է�");
		int employeeId = DBConn.inputInt();
		
		JobsWithEmployeesDto dto = new JobsWithEmployeesDto();
		dto.setEmployeeId(employeeId);
		
		request.setJe(dto);
		
		JobsWithEmployeesDao dao = new JobsWithEmployeesDao();
		JobsWithEmployeesDto arr = request.getJe();
		response.setArrMainDto(dao.select2(arr.getEmployeeId()));
		
		ArrayList<JobsWithEmployeesDto> dtos = response.getArrMainDto();
		
		
		int id = dtos.get(0).getDepartmentId();
		int min = dtos.get(0).getMinSalary();
		int max = dtos.get(0).getMaxSalary();
		int salary = dtos.get(0).getSalary();
		String job = dtos.get(0).getJobTitle();
		
		System.out.println("���� �޿������� ������ �����ϴ�.");
		
		System.out.println("����ID:"+id);
		System.out.println("����޿�: "+salary);
		System.out.println("��������: "+job);
		System.out.println("MIN:"+min);
		System.out.println("MAX:"+max);
		
		
		System.out.println("������ �޿��Է�");
			salary = DBConn.inputInt();
			
			if(salary>= min && salary<=max) {
				dto.setSalary(salary);
				dto.setEmployeeId(employeeId);
				request.setJe(dto);
			}else {
				System.out.println("�߸��� �޿����� ");
				MainSwitch ms = new MainSwitch();
				ms.SwitchMenu();
			}
	}

	@Override
	public void logic(Request request, Response response) {
		JobsWithEmployeesDto dto = request.getJe();
		JobsWithEmployeesDao dao = new JobsWithEmployeesDao();
		dao.updateSal(dto.getSalary(),dto.getEmployeeId());
		
		
	}

	@Override
	public void outputView(Request request, Response response) {
		System.out.println(request.getJe().getEmployeeId()+"�� ����� �޿���");
		System.out.println(request.getJe().getSalary()+"����Ǿ����ϴ�.");
			
	}
}
