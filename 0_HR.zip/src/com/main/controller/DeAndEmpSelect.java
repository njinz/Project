package com.main.controller;

import java.util.ArrayList;
import com.main.dao.DeAndEmpDao;
import com.main.dto.DeAndEmpDto;
import com.main.util.Request;
import com.main.util.Response;

public class DeAndEmpSelect implements MainExecute {
	@Override
	public void execute(Request request, Response response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Request request, Response response) {
		System.out.println("Department and Employees.");
		
	}

	@Override
	public void logic(Request request, Response response) {
		DeAndEmpDao dao = new DeAndEmpDao();
		response.setArrDaeDto(dao.DeAndEmpSelect());
		
		
	}

	@Override
	public void outputView(Request request, Response response) {
		
		if(response!=null) {
			ArrayList<DeAndEmpDto> dtos = response.getArrDaeDto();
			System.out.println("���������.");
			for(DeAndEmpDto dto:dtos) {
				System.out.println(dto);
			}
		}else {
			System.out.println("�����������ϴ�.");
		}
		
	}
}
