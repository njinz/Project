package com.main.util;

import java.util.ArrayList;

import com.main.dto.DeAndEmpDto;
import com.main.dto.DeAndLocationsDto;
import com.main.dto.JobHistoryWithEmployeesDto;
import com.main.dto.Jobs_jobHistoryDto;
import com.main.dto.JobsWithEmployeesDto;

public class Response {
	//Dto�� ����Ʈ�� �߰� ���ְ� getter setter ������ָ��
	private ArrayList<DeAndLocationsDto> arrde_loDto = new ArrayList<DeAndLocationsDto>();
	private ArrayList<JobsWithEmployeesDto> arrMainDto = new ArrayList<JobsWithEmployeesDto>();
	private ArrayList<JobHistoryWithEmployeesDto> arrJHDto = new ArrayList<JobHistoryWithEmployeesDto>();
	private ArrayList<DeAndEmpDto> arrDaeDto = new ArrayList<DeAndEmpDto>();
	private ArrayList<Jobs_jobHistoryDto> arrjhDto = new ArrayList<Jobs_jobHistoryDto>();
	private int resultValue = 0;
	
	

	public ArrayList<DeAndLocationsDto> getArrde_loDto() {
		return arrde_loDto;
	}
	public void setArrde_loDto(ArrayList<DeAndLocationsDto> arrde_loDto) {
		this.arrde_loDto = arrde_loDto;
	}
	public ArrayList<Jobs_jobHistoryDto> getArrjhDto() {
		return arrjhDto;
	}
	public void setArrjhDto(ArrayList<Jobs_jobHistoryDto> arrjhDto) {
		this.arrjhDto = arrjhDto;
	}
	public ArrayList<DeAndEmpDto> getArrDaeDto() {
		return arrDaeDto;
	}
	public void setArrDaeDto(ArrayList<DeAndEmpDto> arrDaeDto) {
		this.arrDaeDto = arrDaeDto;
	}
	public ArrayList<JobHistoryWithEmployeesDto> getArrJHDto() {
		return arrJHDto;
	}
	public void setArrJHDto(ArrayList<JobHistoryWithEmployeesDto> arrJHDto) {
		this.arrJHDto = arrJHDto;
	}
	public ArrayList<JobsWithEmployeesDto> getArrMainDto() {
		return arrMainDto;
	}
	public void setArrMainDto(ArrayList<JobsWithEmployeesDto> arrMainDto) {
		this.arrMainDto = arrMainDto;
	}
	public int getResultValue() {
		return resultValue;
	}
	public void setResultValue(int resultValue) {
		this.resultValue = resultValue;
	}
	
	
}
