package com.main.util;

import com.human.dto.JobsDto;
import com.main.dto.JobsWithEmployeesDto;
//���������� ?
public class Request {
	
	private JobsDto jobsDto = null;
	private JobsWithEmployeesDto je = null;

	public JobsWithEmployeesDto getJe() {
		return je;
	}

	public void setJe(JobsWithEmployeesDto je) {
		this.je = je;
	}

	public JobsDto getJobsDto() {
		return jobsDto;
	}

	public void setJobsDto(JobsDto jobsDto) {
		this.jobsDto = jobsDto;
	}
	
}
