package com.main.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.human.jobs.util.DBConn;
import com.main.dto.DeAndLocationsDto;

public class DeAndLocationsDao {
	public ArrayList<DeAndLocationsDto> DeWithLocationsSelect(){
		ArrayList<DeAndLocationsDto> dtos = new ArrayList<DeAndLocationsDto>();
		DBConn.getInstance();
		String sql = "select * from departments d , locations l where d.location_id=l.location_id "
				+ "order by department_id";
		
		ResultSet rs = DBConn.statementQuery(sql);
		try {
			while(rs.next()) {
				DeAndLocationsDto dto = new DeAndLocationsDto();
				
				dto.setDepartment_id(rs.getInt("department_id"));
				dto.setDepartment_name(rs.getString("department_name"));
				dto.setManager_id(rs.getInt("manager_id"));
				dto.setLocation_id(rs.getInt("location_id"));
				dto.setStreet_address(rs.getString("street_address"));
				dto.setPostal_code(rs.getString("postal_code"));
				dto.setCity(rs.getString("city"));
				dto.setState_province(rs.getString("state_province"));
				dto.setCountry_id(rs.getString("country_id"));
				
				dtos.add(dto);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return dtos;
	}
}