package com.main.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.human.dto.EmployeesDto;
import com.main.dto.JobHistoryWithEmployeesDto;
import com.main.dto.JobsWithEmployeesDto;
import com.main.util.DBConn;

public class JobHistoryWithEmployeesDao {
	
	public ArrayList<JobHistoryWithEmployeesDto> JobsWithEmployeesSelect() {
		ArrayList<JobHistoryWithEmployeesDto> dtos = new ArrayList<JobHistoryWithEmployeesDto>();
		
		DBConn.getInstance();
		String sql = "select j.employee_id,j.start_date,j.end_date, "
				+ "j.job_id,j.department_id,e.first_name,e.last_name, "
				+ "e.email, e.phone_number,e.hire_date,e.job_id,e.salary,"
				+ "e.commission_pct, e.manager_id,e.department_id from job_history j,employees e"+
				" where j.employee_id = e.employee_id";
		
		ResultSet rs = DBConn.statementQuery(sql);

		try {
			while (rs.next()) {
				JobHistoryWithEmployeesDto dto = new JobHistoryWithEmployeesDto();
				
				dto.setEmployeeId(rs.getInt("employee_id"));
				dto.setStartDate(rs.getString("start_date"));
				dto.setEndDate(rs.getString("end_date"));
				dto.setJobId(rs.getString("job_id"));
				dto.setDepartmentId(rs.getInt("department_id"));
				
				dto.setEmployeeId(rs.getInt("employee_id"));
				dto.setFirstName(rs.getString("first_name"));
				dto.setLastName(rs.getString("last_name"));
				dto.setEmail(rs.getString("email"));
				dto.setPhoneNumber(rs.getString("phone_number"));
				dto.setHireDate(rs.getDate("hire_date"));
				dto.setJobId(rs.getString("job_id"));
				dto.setSalary(rs.getInt("salary"));
				dto.setCommissionPct(rs.getDouble("commission_pct"));
				dto.setManagerId(rs.getInt("manager_id"));
				dto.setDepartmentId(rs.getInt("department_id"));
				
				

				dtos.add(dto);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}

}