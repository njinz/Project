package com.main.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.human.dto.EmployeesDto;
import com.main.dto.JobsWithEmployeesDto;
import com.main.util.DBConn;

public class JobsWithEmployeesDao {
	public int insert(EmployeesDto dto) {
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "insert into employees values (%d,'%s','%s','%s','%s',"
				+ "to_date('%s','yyyy-mm-dd hh24:mi:ss'),'%s',%d, %f, %d, %d )";
		
		sql = String.format(sql, dto.getEmployeeId(), dto.getFirstName(), dto.getLastName(), dto.getEmail(),
				dto.getPhoneNumber(), DBConn.dateToString(dto.getHireDate()), dto.getJobId(), dto.getSalary(),
				dto.getCommissionPct(), dto.getManagerId(), dto.getDepartmentId());

		DBConn.statementUpdate(sql);
		DBConn.dbClose();

		return returnvalue;
	}

	public int update(String firstname, int employeeId) {
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Employees set First_Name = '%s' where employee_Id = %d";

		sql = String.format(sql, firstname, employeeId);

		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;

	}
	public int updateSal(int salary,int employeeId) {
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Employees set salary = %d where employee_Id = %d";

		sql = String.format(sql,salary,employeeId);

		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;

	}
	

	public int delete(int employeeId) {
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "delete from Employees where employee_Id = %d";

		sql = String.format(sql, employeeId);

		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
	}

	public ArrayList<JobsWithEmployeesDto> select() {
		ArrayList<JobsWithEmployeesDto> dtos = new ArrayList<JobsWithEmployeesDto>();
		
		DBConn.getInstance();
		String sql = "select j.Job_ID,j.Job_title,j.min_salary,j.max_salary,e.employee_id,e.first_name,e.last_name,e.email,e.phone_number,e.hire_date,e.job_id,e.salary,e.commission_pct,e.manager_id,e.department_id" 
				+" from Jobs j,employees e"+
				" where j.job_id = e.job_id"
				+ " order by e.employee_id";
		
		ResultSet rs = DBConn.statementQuery(sql);

		try {
			while (rs.next()) {
				JobsWithEmployeesDto dto = new JobsWithEmployeesDto();
				dto.setJobId(rs.getString("job_id"));
				dto.setJobTitle(rs.getString("job_title"));
				dto.setMinSalary(rs.getInt("min_salary"));
				dto.setMaxSalary(rs.getInt("max_salary"));
				
				dto.setEmployeeId(rs.getInt("employee_id"));
				dto.setFirstName(rs.getString("first_name"));
				dto.setLastName(rs.getString("last_name"));
				dto.setEmail(rs.getString("email"));
				dto.setPhoneNumber(rs.getString("phone_number"));
				dto.setHireDate(rs.getDate("hire_date"));
				dto.setJobId(rs.getString("job_id"));
				dto.setSalary(rs.getInt("salary"));
				dto.setCommissionPct(rs.getDouble("commission_pct"));
				dto.setManagerId(rs.getInt("manager_id"));
				dto.setDepartmentId(rs.getInt("department_id"));

				dtos.add(dto);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}
	
	public ArrayList<JobsWithEmployeesDto> select2(int employeeId) {
		ArrayList<JobsWithEmployeesDto> dtos = new ArrayList<JobsWithEmployeesDto>();
		
		DBConn.getInstance();
		String sql = "select j.Job_ID,j.Job_title,j.min_salary,j.max_salary,e.employee_id,e.first_name,e.last_name,e.email,e.phone_number,e.hire_date,e.job_id,e.salary,e.commission_pct,e.manager_id,e.department_id" 
				+" from Jobs j,employees e"+
				" where j.job_id = e.job_id and employee_Id = %d"
				+ " order by e.employee_id";
		
		sql = String.format(sql,employeeId);
		System.out.println(sql);
		
		ResultSet rs = DBConn.statementQuery(sql);

		try {
			while (rs.next()) {
				JobsWithEmployeesDto dto = new JobsWithEmployeesDto();
				dto.setJobId(rs.getString("job_id"));
				dto.setJobTitle(rs.getString("job_title"));
				dto.setMinSalary(rs.getInt("min_salary"));
				dto.setMaxSalary(rs.getInt("max_salary"));
				
				dto.setEmployeeId(rs.getInt("employee_id"));
				dto.setFirstName(rs.getString("first_name"));
				dto.setLastName(rs.getString("last_name"));
				dto.setEmail(rs.getString("email"));
				dto.setPhoneNumber(rs.getString("phone_number"));
				dto.setHireDate(rs.getDate("hire_date"));
				dto.setJobId(rs.getString("job_id"));
				dto.setSalary(rs.getInt("salary"));
				dto.setCommissionPct(rs.getDouble("commission_pct"));
				dto.setManagerId(rs.getInt("manager_id"));
				dto.setDepartmentId(rs.getInt("department_id"));

				dtos.add(dto);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}

}
