package com.main.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.main.dto.Jobs_jobHistoryDto;
import com.main.util.DBConn;

public class JobsAndHistoryDao {
	
	public ArrayList<Jobs_jobHistoryDto> select_jh_jobs(){
		ArrayList<Jobs_jobHistoryDto> AllDtos = new ArrayList<Jobs_jobHistoryDto>();
		DBConn.getInstance();
		String sql = "select j.job_id,jh.department_id from job_history jh, jobs j" +
		" where jh.job_id=j.job_id";
		ResultSet rs = DBConn.statementQuery(sql);
		try {
			while(rs.next()) {
				Jobs_jobHistoryDto alldto = new Jobs_jobHistoryDto();
				alldto.setJobId(rs.getString("job_id"));
				alldto.setDepartmentId(rs.getInt("department_id"));
				
				AllDtos.add(alldto);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
			return AllDtos;
		}
}
