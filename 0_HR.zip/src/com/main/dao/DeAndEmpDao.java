package com.main.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.main.dto.DeAndEmpDto;
import com.main.dto.JobHistoryWithEmployeesDto;
import com.main.util.DBConn;

public class DeAndEmpDao {
	public ArrayList<DeAndEmpDto> DeAndEmpSelect() {
		ArrayList<DeAndEmpDto> dtos = new ArrayList<DeAndEmpDto>();
		
		DBConn.getInstance();
		String sql = "select d.department_id,d.department_name,d.manager_id,d.location_id,"
				+ "e.employee_id,e.first_name,e.last_name,"
				+ "e.email, e.phone_number,e.hire_date,e.job_id,e.salary,"
				+ "e.commission_pct, e.manager_id,e.department_id from departments d,employees e"+
				" where d.department_id = e.department_id"
				+ " order by d.department_id";

		
		ResultSet rs = DBConn.statementQuery(sql);

		try {
			while (rs.next()) {
				DeAndEmpDto dto = new DeAndEmpDto();
				
				dto.setDepartmentId(rs.getInt("department_id"));
				dto.setDepartmentName(rs.getString("department_name"));
				dto.setManagerId(rs.getInt("manager_id"));
				dto.setLocationId(rs.getInt("location_id"));
				
				dto.setEmployeeId(rs.getInt("employee_id"));
				dto.setFirstName(rs.getString("first_name"));
				dto.setLastName(rs.getString("last_name"));
				dto.setEmail(rs.getString("email"));
				dto.setPhoneNumber(rs.getString("phone_number"));
				dto.setHireDate(rs.getDate("hire_date"));
				dto.setJobId(rs.getString("job_id"));
				dto.setSalary(rs.getInt("salary"));
				dto.setCommissionPct(rs.getDouble("commission_pct"));
				dto.setManagerId(rs.getInt("manager_id"));
				//dto.setDepartmentId(rs.getInt("department_id"));
				
				

				dtos.add(dto);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}
}
