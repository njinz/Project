package com.human.jobhistory.util;

import com.human.dto.JobHistoryDto;

public class Request {
	private JobHistoryDto jobHistoryDto=null;

	public JobHistoryDto getJobHistoryDto() {
		return jobHistoryDto;
	}

	public void setJobHistoryDto(JobHistoryDto jobHistoryDto) {
		this.jobHistoryDto = jobHistoryDto;
	}

}
