package com.human.controller;

import java.util.ArrayList;
import com.human.dao.JobHistoryDao;
import com.human.dto.JobHistoryDto;
import com.human.jobhistory.util.DBConn;
import com.human.jobhistory.util.Request;
import com.human.jobhistory.util.Response;

public class JobHistoryUpdateEndDate implements JobHistoryExecute{
	
	@Override
	public void execute() {
		JobHistoryDto request=new JobHistoryDto();
		ArrayList<Integer> response=new ArrayList<Integer>();
	}
	
	@Override
	public void execute(Request request, Response response) {
		inputView(request,response);
		logic(request,response);
		outputView(request,response);		
	}

	@Override
	public void inputView(Request request, Response response) {//��ü����
		System.out.println("������ ID�Է�");
		int id = DBConn.inputInt();
		System.out.println("������ �μ� �Է�");
		int deptId = DBConn.inputInt();
		System.out.println("����ID �Է�");
		String jobId = DBConn.inputString();
		System.out.println("������ ���ᳯ¥ �Է� (YY-MM-DD)");
		String endDate = DBConn.inputString();
		
		JobHistoryDto dto=new JobHistoryDto();	
		
		dto.setEmployeeId(id);
		dto.setEndDate(endDate);
		dto.setJobId(jobId);
		dto.setDepartmentId(deptId);
		request.setJobHistoryDto(dto);
	}

	@Override
	public void logic(Request request, Response response) {
		JobHistoryDto dto=request.getJobHistoryDto();		
		JobHistoryDao dao=new JobHistoryDao();
		
		int i=dao.updateEndDate(dto.getEndDate(),dto.getEmployeeId(),dto.getJobId(),dto.getDepartmentId());
		
		response.setResultValue(i);
	}

	@Override
	public void outputView(Request request, Response response) {
		
		System.out.println(request.getJobHistoryDto().getEmployeeId()+"�� ");
		System.out.println(request.getJobHistoryDto().getEndDate()+"�� ������¥�� ����Ǿ����ϴ�.");
		
	}

} 
