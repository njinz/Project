package com.human.controller;

import java.util.ArrayList;
import com.human.dao.JobHistoryDao;
import com.human.dto.JobHistoryDto;
import com.human.jobhistory.util.DBConn;
import com.human.jobhistory.util.Request;
import com.human.jobhistory.util.Response;

public class JobHistoryUpdateStartDate implements JobHistoryExecute{
	
	@Override
	public void execute() {
		JobHistoryDto request=new JobHistoryDto();
		ArrayList<Integer> response=new ArrayList<Integer>();
	}
	
	@Override
	public void execute(Request request, Response response) {
		inputView(request,response);
		logic(request,response);
		outputView(request,response);		
	}

	@Override
	public void inputView(Request request, Response response) {//���۳�¥ ����
		System.out.println("������ ������ ID�Է�");
		int id = DBConn.inputInt();
		System.out.println("���� ��¥ �Է�");
		String startDate=DBConn.inputString();
		
		JobHistoryDto dto=new JobHistoryDto();	
		
		dto.setStartDate(startDate);		
		dto.setEmployeeId(id);
		request.setJobHistoryDto(dto);
	}

	@Override
	public void logic(Request request, Response response) {
		JobHistoryDto dto=request.getJobHistoryDto();		
		JobHistoryDao dao=new JobHistoryDao();
		
		int i=dao.updateStartDate(dto.getStartDate(),dto.getEmployeeId());
		
		response.setResultValue(i);
	}

	@Override
	public void outputView(Request request, Response response) {
		
		System.out.println(request.getJobHistoryDto().getEmployeeId()+"�� ");
		System.out.println(request.getJobHistoryDto().getStartDate()+"�� ���۳�¥�� ����Ǿ����ϴ�.");
		
	}

} 
