package com.human.test;

import java.util.Scanner;
import com.human.controller.JobHistoryDelete;
import com.human.controller.JobHistoryExecute;
import com.human.controller.JobHistoryInsert;
import com.human.controller.JobHistorySelect;
import com.human.controller.JobHistoryUpdateAll;
import com.human.jobhistory.util.Request;
import com.human.jobhistory.util.Response;

public class Test {

	public static void main(String[] args) {
		
		
		JobHistoryExecute pe=null;
		Response response=new Response();
		Request request=new Request();

		System.out.println("0:�Է� 1:���� 2:���� 3:���");
		Scanner sc=new Scanner(System.in);
		String select=sc.nextLine();
		
		switch(select) {
			case "0":
				pe=new JobHistoryInsert();
				break;
			case "1":
				pe=new JobHistoryUpdateAll();
				break;	
			case "2":
				pe=new JobHistoryDelete();
				break;
			case "3":
				pe=new JobHistorySelect();
			default:
				break;
		}
		pe.execute(request, response);			
	}

}
