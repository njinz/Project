package com.human.jobs.util;

import com.human.dto.JobsDto;

public class Request {
	private JobsDto jobsDto = null;

	public JobsDto getJobsDto() {
		return jobsDto;
	}

	public void setJobsDto(JobsDto jobsDto) {
		this.jobsDto = jobsDto;
	}
	
	
}
