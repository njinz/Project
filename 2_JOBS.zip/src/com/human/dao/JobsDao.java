package com.human.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.human.dto.JobsDto;
import com.human.jobs.util.DBConn;

public class JobsDao {
	public int insert(JobsDto dto) {
		int returnValue = 0;
		DBConn.getInstance();
		String sql = "insert into jobs "
				+"values ('%s', '%s', %d, %d)";
		sql = String.format(sql, dto.getJobId(), 
				dto.getJobTitle(), dto.getMinSalary(), dto.getMaxSalary());
		
		returnValue = DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
	}
	
	public int updateAll(String jobTitle, String jobId ,int min , int max ) {//��ü ���� 
		int returnValue = 0;
		DBConn.getInstance();
		String sql = "update jobs set job_title ='%s',min_salary=%d , max_salary= %d where job_id = '%s'";
		sql = String.format(sql,jobTitle,min,max,jobId);
		returnValue = DBConn.statementUpdate(sql);
		DBConn.dbClose();
				
		return returnValue;
	}
	public int updateTitle(String jobTitle, String jobId) {//���� Ÿ��Ʋ ����
		int returnValue = 0;
		DBConn.getInstance();
		String sql = "update jobs set job_title ='%s' where job_id = '%s'";
		sql = String.format(sql,jobTitle,jobId);
		returnValue = DBConn.statementUpdate(sql);
		DBConn.dbClose();
				
		return returnValue;
	}
	public int updateMin(String jobId ,int min) {//�ּ� ���� ����
		int returnValue = 0;
		DBConn.getInstance();
		String sql = "update jobs set min_salary=%d where job_id = '%s'";
		sql = String.format(sql,min,jobId);
		returnValue = DBConn.statementUpdate(sql);
		DBConn.dbClose();
				
		return returnValue;
	}
	public int updateMax(String jobId,int max ) {//�ִ� ���� ����
		int returnValue = 0;
		DBConn.getInstance();
		String sql = "update jobs set max_salary= %d where job_id = '%s'";
		sql = String.format(sql,max,jobId);
		returnValue = DBConn.statementUpdate(sql);
		DBConn.dbClose();
				
		return returnValue;
	}
	
	public int delete(String jobId) {
		int returnValue = 0;
		DBConn.getInstance();
		String sql = "delete jobs where job_id like '%s'";
		
		sql = String.format(sql, jobId);
		returnValue = DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnValue;
		
	}
	public ArrayList<JobsDto> select(){
		
		ArrayList<JobsDto> dtos = new ArrayList<JobsDto>();
		DBConn.getInstance();
		String sql = "select * from jobs";
		ResultSet rs = DBConn.statementQuery(sql);
		try {
			while(rs.next()) {
				JobsDto dto = new JobsDto();
				
				dto.setJobId(rs.getString("job_id"));
				dto.setJobTitle(rs.getString("job_title"));
				dto.setMinSalary(rs.getInt("min_salary"));
				dto.setMaxSalary(rs.getInt("max_salary"));
				
				dtos.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dtos;
	}
}
