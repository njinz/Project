package com.human.controller;

import java.util.ArrayList;

import com.human.dao.JobsDao;
import com.human.dto.JobsDto;
import com.human.jobs.util.DBConn;


public class JobsDelete implements JobsExecute{


	@Override
	public void execute(Object request, Object response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Object request, Object response) {
		System.out.println("������ ���� ������ �Է��ϼ���.");
		System.out.println("job_id �Է�");
		String jobId = DBConn.inputString();
		
		JobsDto dto = (JobsDto)request;
		dto.setJobId(jobId);
		
	}

	@Override
	public void logic(Object request, Object response) {
		JobsDto dto = (JobsDto)request;
		JobsDao dao = new JobsDao();
		int i = dao.delete(dto.getJobId());
		
		((ArrayList<Integer>)response).add(new Integer(i));
		
	}

	@Override
	public void outputView(Object request, Object response) {
		
		System.out.println(((ArrayList<Integer>)response).get(0)+" �� ���� �߽��ϴ�.");
	
		
	}
}
