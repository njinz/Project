package com.human.controller;

import java.util.ArrayList;

import com.human.dao.JobsDao;
import com.human.dto.JobsDto;
import com.human.jobs.util.DBConn;


public class JobsInsert implements JobsExecute{



	@Override
	public void execute(Object request, Object response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Object request, Object response) {
		System.out.println("���� ������ �Է��ϼ���.");
		System.out.println("job_id �Է�");
		String jobId = DBConn.inputString();
		System.out.println("job_title �Է�");
		String jobTitle = DBConn.inputString();
		System.out.println("min_salary �Է�");
		int minSalary = DBConn.inputInt();
		System.out.println("max_salary �Է�");
		int maxSalary = DBConn.inputInt();

		JobsDto dto = (JobsDto) request;
		dto.setJobId(jobId);
		dto.setJobTitle(jobTitle);
		dto.setMinSalary(minSalary);
		dto.setMaxSalary(maxSalary);
		
		
		
	}

	@Override
	public void logic(Object request, Object response) {
		JobsDto dto = (JobsDto)request;
		JobsDao dao = new JobsDao();
		int i = dao.insert(dto);
		
		((ArrayList<Integer>)response).add(new Integer(i));
		
		
	}

	@Override
	public void outputView(Object request, Object response) {
		System.out.println(((ArrayList<Integer>)response).get(0));
		
	}

	

	
}
