package com.human.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DBConn {
	
	private DBConn() {};
	private static Connection dbConn=null;
	private static Statement st=null;
	private static ResultSet rs=null;
	private static Scanner sc=new Scanner(System.in);
	
	//getInstance()
	public static Connection getInstance() {
		if(dbConn==null) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url = "jdbc:oracle:thin:@localhost:1521:xe";
				String user="human";
				String pw="human";
				dbConn=DriverManager.getConnection(url,user,pw);
				System.out.println("���Ӽ���!");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dbConn;
		
	}
	
	//statementQuery
	public static ResultSet StatementQuery(String sql) {
		
			try {
				if(st==null) {
				st = dbConn.createStatement();
			} 
				rs=st.executeQuery(sql);
			}catch (SQLException e) {
				e.printStackTrace();
				System.out.println("����!");
			}finally {
				
			}
		return rs;
	}
	
	//statementUpdate
	public static int statementUpdate(String sql) {
		int resultValue=0;
		
			try {
				if(st==null) {
				st=dbConn.createStatement();
			} 
			resultValue =st.executeUpdate(sql);
			}catch (SQLException e) {
				e.printStackTrace();
			}
		return resultValue;
	}
	
	//dbClose
	public static void dbClose() {
		
			try {
				if(rs!=null)rs.close();
				if(st!=null)st.close();
				if(dbConn!=null)dbConn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				rs=null;
				st=null;
				dbConn=null;
			}
	}
	
	//������Է�
	public static int inputInt() {
		System.out.print("�����Է�>>");
		return Integer.parseInt(sc.nextLine());
	}
	public static double inputDouble() {
		System.out.print("�Ǽ��Է�>>");
		return Double.parseDouble(sc.nextLine());
	}
	public static String inputString() {
		System.out.print("���ڿ��Է�>>");
		return sc.nextLine();
	}
	//���ڿ��� ��¥�������� ��ȯ
	public static Date inputDate() {
		Date returnValue = null;
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		System.out.print("��¥�Է�(yyyy-MM-dd)>>");
		String inputString=sc.nextLine();
		
			try {
				returnValue = transFormat.parse(inputString);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		
		return returnValue;
	}
	
	//��¥�� ���ڿ��� ��ȯ
	public static String dateToString(Date d) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		return df.format(d);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
