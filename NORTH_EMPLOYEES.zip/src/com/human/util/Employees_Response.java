package com.human.util;

import java.util.ArrayList;

import com.human.dto.EmployeesDto;

public class Employees_Response {

	private ArrayList<EmployeesDto> arrEmployeesDto = null;
	private int resultValue=0;                   //changed counting ����
	
	//setter getter
	public ArrayList<EmployeesDto> getArrEmployeesDto() {
		return arrEmployeesDto;
	}
	public void setArrEmployeesDto(ArrayList<EmployeesDto> arrEmployeesDto) {
		this.arrEmployeesDto = arrEmployeesDto;
	}
	public int getResultValue() {
		return resultValue;
	}
	public void setResultValue(int resultValue) {
		this.resultValue = resultValue;
	}
	
	

}
