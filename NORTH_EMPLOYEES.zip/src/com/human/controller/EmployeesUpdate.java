package com.human.controller;

import java.util.ArrayList;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.util.DBConn;
import com.human.util.Employees_Request;
import com.human.util.Employees_Response;

public class EmployeesUpdate implements EmployeesExecute {

	@Override
	public void execute() {
		EmployeesDto request = new EmployeesDto();
		ArrayList<Integer> response = new ArrayList<Integer>();
		
	}

	@Override
	public void execute(Employees_Request request, Employees_Response response) {
		inputView(request,response);
		logic(request, response);
		outputView(request,response);
		
	}

	@Override
	public void inputView(Employees_Request request, Employees_Response response) {
		System.out.println("������ ȸ���� ȸ����ȣ�� �ٲ� �̸��� �Է��ϼ���.");
		System.out.println("Employees Id�Է�");
		int no = DBConn.inputInt();
		System.out.println("�ٲ� last name�Է�");
		String LastName = DBConn.inputString();
		
		System.out.println("�ٲ� first name�Է�");
		String FirstName = DBConn.inputString();
		
		EmployeesDto dto = new EmployeesDto();
		dto.setEmployeeID(no);
		dto.setLastName(LastName);
		dto.setFirstName(FirstName);
		request.setEmployeesDto(dto);
		
	}

	@Override
	public void logic(Employees_Request request, Employees_Response response) {
		EmployeesDto dto = request.getEmployeesDto();
		EmployeesDao dao = new EmployeesDao();
		int i = dao.update(dto.getLastName(), dto.getFirstName(), dto.getEmployeeID());
		response.setResultValue(i);
	}

	@Override
	public void outputView(Employees_Request request, Employees_Response response) {
		System.out.println(request.getEmployeesDto().getEmployeeID()+ "�� �������� �̸��� "
				+ request.getEmployeesDto().getLastName() + request.getEmployeesDto().getFirstName()+
				"���� " + response.getResultValue()+ "�� �����߽��ϴ�.");
		
		
	}

}
