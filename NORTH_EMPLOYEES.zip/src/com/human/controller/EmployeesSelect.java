package com.human.controller;

import java.util.ArrayList;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.util.Employees_Request;
import com.human.util.Employees_Response;

public class EmployeesSelect implements EmployeesExecute {

	@Override
	public void execute() {
		EmployeesDto request = new EmployeesDto();
		ArrayList<EmployeesDto> response = new ArrayList<EmployeesDto>();
	}

	@Override
	public void execute(Employees_Request request, Employees_Response response) {
		inputView(request, response);
		logic(request, response);
		outputView(request, response);
		
	}

	@Override
	public void inputView(Employees_Request request, Employees_Response response) {
		System.out.println("��� ȸ���� ����� �����Դϴ�.");
	}

	@Override
	public void logic(Employees_Request request, Employees_Response response) {
		EmployeesDao dao = new EmployeesDao();
		response.setArrEmployeesDto(dao.select());
	}

	@Override
	public void outputView(Employees_Request request, Employees_Response response) {
		if(response!=null) {
			ArrayList<EmployeesDto> dtos = response.getArrEmployeesDto();
			System.out.println("ȸ�������� ������ �����ϴ�.");
			
			for(EmployeesDto dto :dtos) {
				System.out.println(dto);
			}
		}else {
			System.out.println("ȸ�������� �����ϴ�.");
		}
		
	}
	
}
