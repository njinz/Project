package com.human.employees.util;

import java.util.ArrayList;

import com.human.dto.EmployeesDto;

public class Response {
	private ArrayList<EmployeesDto> arremployeesDto = null;
	private int resultValues = 0;
	
	public ArrayList<EmployeesDto> getArremployeesDto() {
		return arremployeesDto;
	}
	public void setArremployeesDto(ArrayList<EmployeesDto> arrPersonDto) {
		this.arremployeesDto = arrPersonDto;
	}
	public int getResultValues() {
		return resultValues;
	}
	public void setResultValues(int resultValues) {
		this.resultValues = resultValues;
	}
	
	
}
