package com.human.test;





import java.util.ArrayList;
import java.util.Date;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;



public class EmployeesDtoTest {

	public static void main(String[] args) {
		
//		//insert
//		EmployeesDao dao = new EmployeesDao();
//		EmployeesDto dto = new EmployeesDto();
//		dto.setEmployeeId(61);
//		dto.setFirstName("aaa");
//		dto.setLastName("aaa");
//		dto.setEmail("aba");
//		dto.setPhoneNumber("aaa");
//		dto.setHireDate(new Date());
//		dto.setJobId("SH_CLERK");
//		dto.setSalaty(600);
//		dto.setCommissionPct(0.1);
//		dto.setManagerId(103);
//		dto.setDepartmentId(60);
//		
//		int result = dao.insert(dto);
//		System.out.println(result);
		
	
		
//		//update
//		EmployeesDao dao = new EmployeesDao();
//		int result = dao.update("bbb", 600);
//		System.out.println(result);
		
		
//		//delect
//		EmployeesDao dao = new EmployeesDao();
//		int result = dao.delete(600);
//		System.out.println(result);
	

		
		
//		//select
//		EmployeesDao dao = new EmployeesDao();
//		ArrayList<EmployeesDto> dtos = dao.select();
//		for(EmployeesDto a : dtos) {
//			System.out.println(a);
//		}
		
		
		
		

	}

}
