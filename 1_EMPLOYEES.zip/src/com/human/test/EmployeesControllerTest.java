package com.human.test;


import java.util.Scanner;

import com.human.controller.EmployeesDelete;
import com.human.controller.EmployeesExecute;
import com.human.controller.EmployeesInsert;
import com.human.controller.EmployeesSelect;
import com.human.controller.EmployeesRetire;
import com.human.employees.util.Request;
import com.human.employees.util.Response;

public class EmployeesControllerTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);


		EmployeesExecute pe = null;
		Response response = new Response();
		Request request = new Request();
		
		//(60,'aaa','aaa','aa','aaa',sysdate,'SH_CLERK',1,0.1,103,60);
		System.out.println("0.�Է� 1.���� 2.���� 3.���");
		int select = sc.nextInt();
		
		switch(select) {
		
		
		case 1:
			pe = new EmployeesInsert();
			break;
		case 2:
			pe = new EmployeesRetire();
			break;
		case 3:
			pe = new EmployeesDelete();
			break;
		case 4:
			pe = new EmployeesSelect();
		default :
			break;
		}
		pe.execute(request,response);
	
		
	
		
		
	}

}
