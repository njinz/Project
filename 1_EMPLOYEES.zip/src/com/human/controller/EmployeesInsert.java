package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.employees.util.DBConn;
import com.human.employees.util.Request;
import com.human.employees.util.Response;









public class EmployeesInsert implements EmployeesExecute{

	

	public void execute(Request request, Response response) {
		
		inputView(request,response);
		logic(request,response);
		outputView(request,response);
	}

	
	public void inputView(Request request, Response response) {
		System.out.println("ȸ�������� �Է��ϼ���");
		
		System.out.println("employeeId �Է�");
		int employeeId = DBConn.inputInt();
		
		System.out.println("firstName �Է�");
		String firstName = DBConn.inputString();
		
		System.out.println("lastName �Է�");
		String lastName = DBConn.inputString();
		
		System.out.println("email �Է�");
		String email = DBConn.inputString();
		
		System.out.println("phoneNumber �Է�");
		String phoneNumber = DBConn.inputString();
		
		System.out.println("hireDate �Է�");
		System.out.println("ex)1999-05-05 �Է�");
		String hireDate =DBConn.inputString();
		
		System.out.println("���� �ִ� jobId �Է�");
		String jobId = DBConn.inputString();
		
		System.out.println("salaty �Է�");
		int salaty = DBConn.inputInt();
		
		System.out.println("commissionPct �Է�");
		double commissionPct = DBConn.inputDouble();
		
		System.out.println("managerId �Է� �ڽŸ��� �ٸ� ��� employeeId�Է�");
		
		int managerId = DBConn.inputInt();
		
		System.out.println("���� �ִ� departmentId �Է�");
		int departmentId = DBConn.inputInt();
		
		
		
		EmployeesDto dto = new EmployeesDto();
		dto.setEmployeeId(employeeId);
		dto.setFirstName(firstName);
		dto.setLastName(lastName);
		dto.setEmail(email);
		dto.setPhoneNumber(phoneNumber);
		dto.setHireDate(hireDate);
		dto.setJobId(jobId);
		dto.setSalary(salaty);
		dto.setCommissionPct(commissionPct);
		dto.setManagerId(managerId);
		dto.setDepartmentId(departmentId);
		
		request.setEmployeesDto(dto);
	}
	
	
	public void logic(Request request, Response response) {
		EmployeesDto dto = request.getEmployeesDto();  
		EmployeesDao dao = new EmployeesDao();
		int i = dao.insert(dto);
		response.setResultValues(i);

	}
	
	
	public void outputView(Request request, Response response) {
		System.out.println(request.getEmployeesDto());
	}

}




