package com.human.controller;

import java.util.ArrayList;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.employees.util.DBConn;
import com.human.employees.util.Request;
import com.human.employees.util.Response;

public class EmployeesSelect implements EmployeesExecute {
		 
	
	
	public void execute(Request request,Response response) {
		 inputView(request, response);
		 logic(request, response);
		 outputView(request, response);
	}

	public void inputView(Request request,Response response) {
		
		System.out.println("��� ȸ���� ����� �����Դϴ�.");
	}

	public void logic(Request request,Response response) {
		
		EmployeesDao dao = new EmployeesDao();
		response.setArremployeesDto(dao.select());
	
	}

	public void outputView(Request request,Response response) {
		
		if(response != null) {
			ArrayList<EmployeesDto> dtos = response.getArremployeesDto();
			System.out.println("ȸ�������� ������ �����ϴ�.");
			for(EmployeesDto a : dtos) {
				System.out.println(a);
			}
		}else {
			System.out.println("ȸ���� �����ϴ�.");
		}

	}
}




