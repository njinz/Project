package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.employees.util.DBConn;
import com.human.employees.util.Request;
import com.human.employees.util.Response;

public class EmployeesUpdate implements EmployeesExecute {


public void execute(Request request,Response response) {
	
	inputView(request,response);
	logic(request,response);
	outputView(request,response);
	
}


	public void inputView(Request request, Response response) {
		
		
		System.out.println("������ ȸ����ȣ�� �̸��� �Է��Ͻÿ�");
		System.out.println("employeeId �Է�");
		int employeeId = DBConn.inputInt();
		System.out.println("firstname �Է�");
		String firstName = DBConn.inputString();
		System.out.println("Last_name �Է�");
		String lastName = DBConn.inputString();
		System.out.println("Email�Է�");
		String email = DBConn.inputString();
		System.out.println("PhoneNumber �Է�");
		String phoneNumber = DBConn.inputString();
		System.out.println("���볯¥ �Է�");
		String hireDate = DBConn.inputString();
		System.out.println("��������(��ϵ� �����θ� ���氡��)");
		String jobId = DBConn.inputString();
		System.out.println("���޺���");
		int salary = DBConn.inputInt();
		System.out.println("commission_pct �Է�");
		double commission = DBConn.inputDouble();
		System.out.println("��� �Ŵ��� ����");
		int manager = DBConn.inputInt();
		System.out.println("���μ� ����");
		int department = DBConn.inputInt();
		
		
		
		
		EmployeesDto dto = new EmployeesDto();
		dto.setEmployeeId(employeeId);
		dto.setFirstName(firstName);
		dto.setLastName(lastName);
		dto.setEmail(email);
		dto.setPhoneNumber(phoneNumber);
		dto.setHireDate(hireDate);
		dto.setJobId(jobId);
		dto.setSalary(salary);
		dto.setCommissionPct(commission);
		dto.setManagerId(manager);
		dto.setDepartmentId(department);
		request.setEmployeesDto(dto);
	}


	public void logic(Request request, Response response) {
		EmployeesDto dto = request.getEmployeesDto();
		EmployeesDao dao = new EmployeesDao();
		int i = dao.update(dto.getEmployeeId(),dto.getFirstName(),dto.getLastName(),dto.getEmail()
				,dto.getPhoneNumber(),dto.getHireDate(),dto.getJobId(),dto.getSalary(),dto.getCommissionPct()
				,dto.getManagerId(),dto.getDepartmentId());
		response.setResultValues(i);
	}


	public void outputView(Request request, Response response) {
		System.out.println(request.getEmployeesDto().getEmployeeId()+ "�� �������� �̸��� "+
				request.getEmployeesDto().getFirstName()+"���� ����");
	}

}


