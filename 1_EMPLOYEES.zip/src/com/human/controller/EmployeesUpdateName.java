package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.employees.util.DBConn;
import com.human.employees.util.Request;
import com.human.employees.util.Response;

public class EmployeesUpdateName implements EmployeesExecute {


public void execute(Request request,Response response) {
	
	inputView(request,response);
	logic(request,response);
	outputView(request,response);
	
}


	public void inputView(Request request, Response response) {
		
		
		System.out.println("������ ȸ����ȣ�� �̸��� �Է��Ͻÿ�");
		System.out.println("employeeId �Է�");
		int employeeId = DBConn.inputInt();
		System.out.println("firstname �Է�");
		String firstName = DBConn.inputString();
		System.out.println("Last_name �Է�");
		String lastName = DBConn.inputString();
		
		
		EmployeesDto dto = new EmployeesDto();
		dto.setEmployeeId(employeeId);
		dto.setFirstName(firstName);
		dto.setLastName(lastName);
		request.setEmployeesDto(dto);
	}


	public void logic(Request request, Response response) {
		EmployeesDto dto = request.getEmployeesDto();
		EmployeesDao dao = new EmployeesDao();
		int i = dao.updateName(dto.getEmployeeId(),dto.getFirstName(),dto.getLastName());
		response.setResultValues(i);
	}


	public void outputView(Request request, Response response) {
		System.out.println(request.getEmployeesDto().getEmployeeId()+ "�� �������� �̸��� "+
				request.getEmployeesDto().getFirstName()+"���� ����");
	}

}


