package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.employees.util.DBConn;
import com.human.employees.util.Request;
import com.human.employees.util.Response;

public class EmployeesUpdateEmail implements EmployeesExecute {


public void execute(Request request,Response response) {
	
	inputView(request,response);
	logic(request,response);
	outputView(request,response);
	
}


	public void inputView(Request request, Response response) {
		
		
		System.out.println("������ ȸ����ȣ�� �̸����� �Է��Ͻÿ�");
		System.out.println("ȸ����ȣ�Է�");
		int employeeId = DBConn.inputInt();
		System.out.println("�̸��� �Է�");
		String email = DBConn.inputString();
		
		
		EmployeesDto dto = new EmployeesDto();
		dto.setEmployeeId(employeeId);
		dto.setEmail(email);
		request.setEmployeesDto(dto);
	}


	public void logic(Request request, Response response) {
		EmployeesDto dto = request.getEmployeesDto();
		EmployeesDao dao = new EmployeesDao();
		int i = dao.updateEmail(dto.getEmployeeId(),dto.getEmail());
		response.setResultValues(i);
	}


	public void outputView(Request request, Response response) {
		System.out.println(request.getEmployeesDto().getEmployeeId()+ "�� �������� �̸����� "+
			request.getEmployeesDto().getEmail()+" �� ����Ǿ����ϴ�.");
	}

}


