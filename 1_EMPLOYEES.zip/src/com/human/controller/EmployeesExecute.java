package com.human.controller;

import java.util.ArrayList;

import com.human.dto.EmployeesDto;
import com.human.employees.util.Request;
import com.human.employees.util.Response;

public interface EmployeesExecute {

		public void execute(Request request,Response response);
		
		public void inputView(Request request, Response response);
		
		public void logic(Request request, Response response);
		
		public void outputView(Request request, Response response);
	
	
}
