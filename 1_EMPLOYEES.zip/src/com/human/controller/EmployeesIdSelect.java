package com.human.controller;

import java.util.ArrayList;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.employees.util.DBConn;
import com.human.employees.util.Request;
import com.human.employees.util.Response;

public class EmployeesIdSelect implements EmployeesExecute {
		 
	
	
	public void execute(Request request,Response response) {
		 inputView(request, response);
		 logic(request, response);
		 outputView(request, response);
	}

	public void inputView(Request request,Response response) {
		System.out.println("�˻��� ���� ID�Է�");
		int employeeId = DBConn.inputInt();
		
		EmployeesDto dto = new EmployeesDto();
		dto.setEmployeeId(employeeId);
		request.setEmployeesDto(dto);
		
		
	}

	public void logic(Request request,Response response) {
		
		EmployeesDao dao = new EmployeesDao();
		EmployeesDto dto = request.getEmployeesDto();
		response.setArremployeesDto(dao.select(dto.getEmployeeId()));
	
	}

	public void outputView(Request request,Response response) {
		
		if(response != null) {
			ArrayList<EmployeesDto> dtos = response.getArremployeesDto();
			System.out.println("���������� ������ �����ϴ�.");
			for(EmployeesDto a : dtos) {
				System.out.println(a);
			}
		}else {
			System.out.println("������ �����ϴ�.");
		}

	}
}




