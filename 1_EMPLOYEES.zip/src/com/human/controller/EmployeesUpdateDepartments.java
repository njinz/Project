package com.human.controller;

import com.human.dao.EmployeesDao;
import com.human.dto.EmployeesDto;
import com.human.employees.util.DBConn;
import com.human.employees.util.Request;
import com.human.employees.util.Response;

public class EmployeesUpdateDepartments implements EmployeesExecute {
	
public void execute(Request request, Response response) {
	inputView(request,response);
	logic(request,response);
	outputView(request,response);
}
	

	@Override
	public void inputView(Request request, Response response) {
		System.out.println("����ID�� �Է��ϼ���.");
		int employee_id = DBConn.inputInt();
		System.out.println("������  job_id�� �Է��ϼ���.");
		String job_id = DBConn.inputString();
		System.out.println("������ manager_id�� �Է��ϼ���.");
		int manager_id = DBConn.inputInt();
		System.out.println("������ department_id�� �Է��ϼ���.");
		int department_id = DBConn.inputInt();
		
		EmployeesDto dto = new EmployeesDto();
		dto.setEmployeeId(employee_id);
		dto.setJobId(job_id);
		dto.setManagerId(manager_id);
		dto.setDepartmentId(department_id);
		request.setEmployeesDto(dto);
	}

	@Override
	public void logic(Request request, Response response) {
		EmployeesDto dto = request.getEmployeesDto();
		EmployeesDao dao = new EmployeesDao();
		int i = dao.updateDepartments(dto.getJobId(),dto.getManagerId(),dto.getDepartmentId(),dto.getEmployeeId());
		response.setResultValues(i);
		
	}

	@Override
	public void outputView(Request request, Response response) {
		System.out.println(request.getEmployeesDto().getEmployeeId()+"�� ����� �μ���" + request.getEmployeesDto().getDepartmentId()+"�� �μ��� �����Ͽ����ϴ�.");
		
	}

}
