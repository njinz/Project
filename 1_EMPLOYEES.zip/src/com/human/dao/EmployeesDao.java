package com.human.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.human.dto.EmployeesDto;
import com.human.employees.util.DBConn;

public class EmployeesDao {
	public int insert(EmployeesDto dto){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "insert into employees values (%d,'%s','%s','%s','%s',"
				+"to_date('%s','yy-mm-dd'),'%s',%d, %f, %d, %d )";
		sql = String.format(sql,dto.getEmployeeId(),dto.getFirstName(),dto.getLastName(),
				dto.getEmail(),dto.getPhoneNumber(),(dto.getHireDate()),
				dto.getJobId(),dto.getSalary(),dto.getCommissionPct(),dto.getManagerId(),
				dto.getDepartmentId());
		
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		
		return returnvalue;
	}
	public int update(int employeeId,String firstName,String lastName,String email,
			String phoneNumber,String hireDate,String jobId,int salary,double commission,int manager
			,int department){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Employees set First_name = '%s',Last_name='%s',Email='%s',Phone_number='%s' "
				+ ",Hire_Date='%s',Job_id='%s',salary=%d,"
				+ "commission_pct=%f,manager_id=%d,department_id=%d where employee_Id = %d";
		
		sql = String.format(sql,firstName,lastName,email,phoneNumber,hireDate,jobId,salary,commission,manager,department,employeeId);
		
		
		DBConn.statementUpdate(sql);
		
		DBConn.dbClose();
		return returnvalue;
		
	}
	
	public int updateEmail(int employeeId,String email){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Employees set email ='%s' where employee_Id = %d";
		
		sql = String.format(sql,email,employeeId);
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
		
	}
	
	public int updateName(int employeeId,String firstName,String lastName){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Employees set First_name = '%s',Last_name='%s' where employee_Id = %d";
		
		sql = String.format(sql,firstName,lastName,employeeId);
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
		
	}
	
	public int updatePhone(int employeeId,String phone){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Employees set phone_number = '%s' where employee_Id = %d";
		
		sql = String.format(sql,phone,employeeId);
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
		
	}
	
	public int updateRetire(int employeeId){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Employees set Job_id='retire' where employee_Id = %d";
		System.out.println(sql);
		sql = String.format(sql,employeeId);
		

		
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
		
	}
	public int delete(int employeeId){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "delete from Employees where employee_Id = %d";
		
		sql = String.format(sql,employeeId);

		
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
	}
	public int updateDepartments(String job_id,int manager_id,int department_id,int employee_id) {
		int returnValue=0;
		DBConn.getInstance();
		
		String sql = "update employees set job_id = '%s', manager_id=%d, department_id=%d"
				+ "where employee_id=%d";
		String sql2 = "update Employees set hire_date=sysdate where employee_Id=%d";
		sql = String.format(sql,job_id,manager_id,department_id,employee_id);
		sql2 = String.format(sql2,employee_id);
		DBConn.statementUpdate(sql);
		DBConn.statementUpdate(sql2);
		DBConn.dbClose();
		return returnValue;
	}
	
	public ArrayList<EmployeesDto> select(){
		ArrayList<EmployeesDto> dtos = new ArrayList<EmployeesDto>();
		DBConn.getInstance();
		String sql = "select * from employees";
		ResultSet rs = DBConn.statementQuery(sql);
		
		try {
			while(rs.next()) {
				EmployeesDto dto = new EmployeesDto();
		
				dto.setEmployeeId(rs.getInt("employee_id"));
				dto.setFirstName(rs.getString("first_name"));
				dto.setLastName(rs.getString("last_name"));
				dto.setEmail(rs.getString("email"));
				dto.setPhoneNumber(rs.getString("phone_number"));
				dto.setHireDate(rs.getString("hire_date"));
				dto.setJobId(rs.getString("job_id"));
				dto.setSalary(rs.getInt("salary"));
				dto.setCommissionPct(rs.getDouble("commission_pct"));
				dto.setManagerId(rs.getInt("manager_id"));
				dto.setDepartmentId(rs.getInt("department_id"));

				dtos.add(dto);
	
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}
	
	public ArrayList<EmployeesDto> select(int employeeId){
		ArrayList<EmployeesDto> dtos = new ArrayList<EmployeesDto>();
		DBConn.getInstance();
		String sql = "select * from employees where employee_id = %d";
		sql = String.format(sql,employeeId);
		ResultSet rs = DBConn.statementQuery(sql);
		
		try {
			while(rs.next()) {
				EmployeesDto dto = new EmployeesDto();
		
				dto.setEmployeeId(rs.getInt("employee_id"));
				dto.setFirstName(rs.getString("first_name"));
				dto.setLastName(rs.getString("last_name"));
				dto.setEmail(rs.getString("email"));
				dto.setPhoneNumber(rs.getString("phone_number"));
				dto.setHireDate(rs.getString("hire_date"));
				dto.setJobId(rs.getString("job_id"));
				dto.setSalary(rs.getInt("salary"));
				dto.setCommissionPct(rs.getDouble("commission_pct"));
				dto.setManagerId(rs.getInt("manager_id"));
				dto.setDepartmentId(rs.getInt("department_id"));

				dtos.add(dto);
	
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}
	
	
	
	
}
