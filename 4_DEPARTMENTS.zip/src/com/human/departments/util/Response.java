package com.human.departments.util;

import java.util.ArrayList;

import com.human.dto.DepartmentsDto;

public class Response {
	private ArrayList<DepartmentsDto> arremployeesDto = null;
	private int resultValues = 0;
	
	public ArrayList<DepartmentsDto> getArremployeesDto() {
		return arremployeesDto;
	}
	public void setArremployeesDto(ArrayList<DepartmentsDto> arrPersonDto) {
		this.arremployeesDto = arrPersonDto;
	}
	public int getResultValues() {
		return resultValues;
	}
	public void setResultValues(int resultValues) {
		this.resultValues = resultValues;
	}
	
	
}
