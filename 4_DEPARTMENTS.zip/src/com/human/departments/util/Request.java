package com.human.departments.util;

import com.human.dto.DepartmentsDto;

public class Request {

	private DepartmentsDto employeesDto = null;

	public DepartmentsDto getDepartmentsDto() {
		return employeesDto;
	}

	public void setDepartmentsDto(DepartmentsDto employeesDto) {
		this.employeesDto = employeesDto;
	}
	

}

