package com.human.controller;

import java.util.ArrayList;

import com.human.dao.DepartmentsDao;
import com.human.departments.util.DBConn;
import com.human.departments.util.Request;
import com.human.departments.util.Response;
import com.human.dto.DepartmentsDto;

public class DepartmentsSelect implements DepartmentsExecute {
		 

	public void execute(Request request,Response response) {
		 inputView(request, response);
		 logic(request, response);
		 outputView(request, response);
	}

	public void inputView(Request request,Response response) {
		
		System.out.println("��� ȸ���� ����� �����Դϴ�.");
	}

	public void logic(Request request,Response response) {
		
		DepartmentsDao dao = new DepartmentsDao();
		response.setArremployeesDto(dao.select());
	
	}

	public void outputView(Request request,Response response) {
		
		if(response != null) {
			ArrayList<DepartmentsDto> dtos = response.getArremployeesDto();
			System.out.println("ȸ�������� ������ �����ϴ�.");
			for(DepartmentsDto a : dtos) {
				System.out.println(a);
			}
		}else {
			System.out.println("ȸ���� �����ϴ�.");
		}

	}
}




