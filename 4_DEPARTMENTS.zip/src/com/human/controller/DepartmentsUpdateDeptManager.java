package com.human.controller;

import java.util.ArrayList;

import com.human.dao.DepartmentsDao;
import com.human.departments.util.DBConn;
import com.human.departments.util.Request;
import com.human.departments.util.Response;
import com.human.dto.DepartmentsDto;

public class DepartmentsUpdateDeptManager implements DepartmentsExecute {


public void execute(Request request,Response response) {
	
	inputView(request,response);
	logic(request,response);
	outputView(request,response);
}


	public void inputView(Request request, Response response) {
		System.out.println("������ �μ�ID�� �Է��ϼ���");
		System.out.println("DepartmentId �Է�");
		int DepartmentId = DBConn.inputInt();
		System.out.println("���Ŵ��� ����");
		int mID = DBConn.inputInt();
		
		
		DepartmentsDto dto = new DepartmentsDto();
		dto.setDepartmentId(DepartmentId);
		dto.setManagerId(mID);
		request.setDepartmentsDto(dto);
	}


	public void logic(Request request, Response response) {
		DepartmentsDto dto = request.getDepartmentsDto();
		DepartmentsDao dao = new DepartmentsDao();
		int i = dao.updateDeptManager(dto.getManagerId(),dto.getDepartmentId());
		response.setResultValues(i);
	}


	public void outputView(Request request, Response response) {
		System.out.println(request.getDepartmentsDto().getDepartmentId()+"��");
		System.out.println("��� �Ŵ����� " +request.getDepartmentsDto().getManagerId()+"�� ����Ǿ����ϴ�");
	}
}


