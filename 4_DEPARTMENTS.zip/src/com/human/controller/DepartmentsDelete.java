package com.human.controller;

import java.util.ArrayList;

import com.human.dao.DepartmentsDao;
import com.human.departments.util.DBConn;
import com.human.departments.util.Request;
import com.human.departments.util.Response;
import com.human.dto.DepartmentsDto;

public class DepartmentsDelete implements DepartmentsExecute {

	
	public void execute(Request request,Response response) {
		inputView(request,response);
		logic(request,response);
		outputView(request,response);
	}

	
	public void inputView(Request request, Response response) {
		System.out.println("������ �μ���ȣ�� �Է��ϼ���(�μ��� �Ҽӵ� ������ ���� ��� ���� �Ұ�)");
		int departmentId = DBConn.inputInt();
		
		DepartmentsDto dto = new DepartmentsDto();
		
		dto.setDepartmentId(departmentId);
		request.setDepartmentsDto(dto);

	}


	public void logic(Request request, Response response) {
		DepartmentsDto dto =request.getDepartmentsDto();
		DepartmentsDao dao = new DepartmentsDao();
		
		int i = dao.delete(dto.getDepartmentName());
		response.setResultValues(i);

	}


	public void outputView(Request request, Response response) {
		System.out.println(request.getDepartmentsDto().getDepartmentName()+"�� �μ��� �����Ǿ����ϴ�.");

	}

}

	

