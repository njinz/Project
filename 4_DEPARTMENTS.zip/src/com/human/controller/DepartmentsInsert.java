package com.human.controller;

import java.util.ArrayList;
import java.util.Date;

import com.human.dao.DepartmentsDao;
import com.human.departments.util.DBConn;
import com.human.departments.util.Request;
import com.human.departments.util.Response;
import com.human.dto.DepartmentsDto;









public class DepartmentsInsert implements DepartmentsExecute{

	

	public void execute(Request request, Response response) {
		
		inputView(request,response);
		logic(request,response);
		outputView(request,response);
	}

	
	public void inputView(Request request, Response response) {
		System.out.println("*���ο� �μ��� �����մϴ�*.");
		
		System.out.println("�μ��� �Է�");
		String departmentName = DBConn.inputString();
		
		System.out.println("���Ŵ���ID �Է�");
		int managerId = DBConn.inputInt();
		
		System.out.println("����ID �Է�");
		int locationId = DBConn.inputInt();
	
		DepartmentsDto dto = new DepartmentsDto();
		dto.setDepartmentName(departmentName);
		dto.setManagerId(managerId);
		dto.setLocationId(locationId);
		
		request.setDepartmentsDto(dto);
	}
	
	
	public void logic(Request request, Response response) {
		DepartmentsDto dto = request.getDepartmentsDto();  
		DepartmentsDao dao = new DepartmentsDao();
		int i = dao.insert(dto);
		response.setResultValues(i);

	}
	
	
	public void outputView(Request request, Response response) {
		System.out.println("���ο� �μ��� �ż��Ǿ����ϴ�.");
		System.out.println("�μ���: "+request.getDepartmentsDto().getDepartmentName());
		System.out.println("���Ŵ���ID: "+request.getDepartmentsDto().getManagerId());
		System.out.println("����ID: "+request.getDepartmentsDto().getLocationId());
	}

}




