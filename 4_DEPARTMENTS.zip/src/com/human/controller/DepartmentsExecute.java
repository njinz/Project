package com.human.controller;

import java.util.ArrayList;

import com.human.departments.util.Request;
import com.human.departments.util.Response;
import com.human.dto.DepartmentsDto;

public interface DepartmentsExecute {

		public void execute(Request request,Response response);
		
		public void inputView(Request request, Response response);
		
		public void logic(Request request, Response response);
		
		public void outputView(Request request, Response response);
	
	
}
