package com.human.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.human.departments.util.DBConn;
import com.human.dto.DepartmentsDto;

public class DepartmentsDao {
	public int insert(DepartmentsDto dto){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "insert into Departments values ('DEPARTMENTS_SEQ.NEXTVAL','%s',%d,%d)";
		System.out.println(sql);
		sql = String.format(sql,dto.getDepartmentName(),dto.getManagerId(),dto.getLocationId());
		
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		
		return returnvalue;
	}
	public int updateAll(String departmentName,int mid,int location,int dptId){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Departments set Department_Name = '%s',manager_Id=%d,"
				+ "Location_ID =%d where Department_Id = %d";
		
		
		sql = String.format(sql,departmentName,mid,location,dptId);
		
		
		DBConn.statementUpdate(sql);
		
		DBConn.dbClose();
		return returnvalue;
		
	}
	
	public int updateDeptName(String departmentName,int dptId){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Departments set Department_Name = '%s' where Department_Id = %d";
		
		sql = String.format(sql,departmentName,dptId);

		
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
		
	}
	
	public int updateDeptManager(int mid,int dptId){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Departments set Manager_Id = %d where Department_Id = %d";
		
		sql = String.format(sql,mid,dptId);

		
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
		
	}
	
	public int updateDeptLocation(int location,int dptId){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "update Departments set Location_id= %d where Department_Id = %d";
		
		sql = String.format(sql,location,dptId);

		
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
		
	}
	public int delete(String string){
		int returnvalue = 0;
		DBConn.getInstance();
		String sql = "delete from Departments where Department_ID = %d";
		
		sql = String.format(sql,string);

		
		DBConn.statementUpdate(sql);
		DBConn.dbClose();
		return returnvalue;
	}
	
	public ArrayList<DepartmentsDto> select(){
		ArrayList<DepartmentsDto> dtos = new ArrayList<DepartmentsDto>();
		DBConn.getInstance();
		String sql = "select * from Departments";
		ResultSet rs = DBConn.statementQuery(sql);
		
		try {
			while(rs.next()) {
				DepartmentsDto dto = new DepartmentsDto();
		
				dto.setDepartmentId(rs.getInt(1));
				dto.setDepartmentName(rs.getString(2));
				dto.setManagerId(rs.getInt(3));
				dto.setLocationId(rs.getInt(4));
			

				dtos.add(dto);
	
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}
	
	
	
	
}
