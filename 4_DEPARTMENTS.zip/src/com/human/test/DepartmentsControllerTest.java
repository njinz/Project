package com.human.test;

import java.util.ArrayList;
import java.util.Scanner;

import com.human.controller.DepartmentsDelete;
import com.human.controller.DepartmentsExecute;
import com.human.controller.DepartmentsInsert;
import com.human.controller.DepartmentsSelect;
import com.human.controller.DepartmentsUpdateAll;
import com.human.departments.util.Request;
import com.human.departments.util.Response;
import com.human.dto.DepartmentsDto;

public class DepartmentsControllerTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String select = "";
		DepartmentsExecute pe = null;
		Response response = new Response();
		Request request = new Request();
		
		//(60,'aaa','aaa','aa','aaa',sysdate,'SH_CLERK',1,0.1,103,60);
		System.out.println("0.�Է� 1.���� 2.���� 3.���");
		select = sc.nextLine();
		switch(select) {
		case "0":
			pe = new DepartmentsInsert();
			break;
		case "1":
			pe = new DepartmentsUpdateAll();
			break;
		case "2":
			pe = new DepartmentsDelete();
			break;
		case "3":
			pe = new DepartmentsSelect();
		default :
			break;
		}
		
		pe.execute(request,response);
		
		
	}

}
